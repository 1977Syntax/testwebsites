import {
    a as m,
    t as f,
    s as r,
    b as t,
    r as s,
    f as K
} from "../chunks/disclose-version.91b4a1e6.js";
import {
    p as Q,
    b as U,
    c as V,
    s as N,
    g as w,
    f as X,
    h,
    i as a
} from "../chunks/runtime.712ce216.js";
import {
    s as O
} from "../chunks/render.95e1ab5e.js";
import {
    i as R
} from "../chunks/if.c692dc35.js";
import {
    e as B,
    i as E
} from "../chunks/each.14627b3c.js";
import {
    s as Y
} from "../chunks/snippet.affc9ce4.js";
import {
    c as Z
} from "../chunks/svelte-component.351a274c.js";
import {
    s as I
} from "../chunks/attributes.0fe580a6.js";
import {
    s as S,
    t as M
} from "../chunks/class.cca9bd46.js";
import {
    d as $
} from "../chunks/svelte-head.5f7b6b5a.js";
import {
    t as ee,
    a as ae
} from "../chunks/index.aac95cae.js";
import {
    T as re,
    L as se
} from "../chunks/TextAlignCenter.db61e814.js";
import {
    L as te
} from "../chunks/Logo.a275c634.js";
import {
    S as oe
} from "../chunks/SvelteMarkdown.4b8552a7.js";
const L = {
    GLOBAL_ALERT: {
        enabled: !0,
        message: "Apple-Ware ALPHA is here! Reports bugs in our [Discord](https://discord.gg/appleware).",
        type: "error"
    }
};
var ie = f('<div><span class="animate-pulse"><!></span></div>'),
    le = f("<a> </a>"),
    ne = (b, v) => {
        N(v, !w(v))
    },
    ce = (b, v) => N(v, !1),
    ve = f("<a> </a>"),
    de = f('<div class="m-nav-container aw-1ou2cig"><div class="flex flex-col gap-10 items-center justify-center h-full"></div></div>'),
    pe = f('<span class="hidden md:block">•</span>'),
    me = f('<a class="hover:underline"> </a> <!>', 1),
    fe = f('<div class="wrapper aw-1ou2cig"><!> <div class="navbar aw-1ou2cig"><!> <div class="hidden md:flex nav-items aw-1ou2cig"></div> <button class="menu aw-1ou2cig"><!></button></div> <!> <div class="content aw-1ou2cig"><!></div> <footer class="aw-1ou2cig"><div class="container mx-auto flex flex-col md:flex-row items-center justify-center gap-4"><!> <span class="hidden md:block">•</span> <span>&copy; 2024 Apple-Ware. All rights reserved.</span></div></footer></div>');

function Re(b, v) {
    Q(v, !0);
    let P = [{
            name: "Home",
            href: "/"
        }, {
            name: "Support",
            href: "https://discord.gg/appleware"
        }, {
            name: "Download",
            href: "/download",
            classes: "btn btn-primary font-semibold"
        }],
        _ = X(!1),
        j = [{
            name: "Privacy Policy",
            href: "/legal/privacy-policy"
        }, {
            name: "Terms of Service",
            href: "/legal/terms-of-service"
        }];
    U(() => {
        document.body.classList.toggle("overflow-y-hidden", w(_))
    });
    var y = fe(),
        C = t(y);
    R(C, () => L.GLOBAL_ALERT && L.GLOBAL_ALERT.enabled, i => {
        var e = ie(),
            l = t(e),
            d = t(l);
        oe(d, {
            get source() {
                return L.GLOBAL_ALERT.message
            },
            isInline: !0
        }), s(l), s(e), h(() => S(e, `page-alert page-alert-${L.GLOBAL_ALERT.type} text-center aw-1ou2cig`)), m(i, e)
    });
    var A = r(r(C, !0)),
        D = t(A);
    te(D, {});
    var x = r(r(D, !0));
    B(x, 73, () => P, E, (i, e, l) => {
        let d = () => a(a(e)).name,
            p = () => a(a(e)).href,
            u = () => a(a(e)).onclick,
            n = () => a(a(e)).classes;
        var o = le();
        o.__click = u();
        var g = t(o);
        s(o), h(() => {
            I(o, "href", p()), S(o, `${n()??""} aw-1ou2cig`), M(o, "nav-link", !0), O(g, d())
        }), m(i, o)
    }), s(x);
    var k = r(r(x, !0));
    k.__click = [ne, _];
    var q = t(k);
    Z(q, () => w(_) ? re : se, (i, e) => {
        e(i, {})
    }), s(k), s(A);
    var H = r(r(A, !0));
    R(H, () => w(_), i => {
        var e = de();
        ee(3, e, () => ae, () => ({
            duration: 150
        })), e.__click = [ce, _];
        var l = t(e);
        B(l, 73, () => P, E, (d, p, u) => {
            let n = () => a(a(p)).name,
                o = () => a(a(p)).href,
                g = () => a(a(p)).classes;
            var c = ve(),
                G = t(c);
            s(c), h(() => {
                I(c, "href", o()), S(c, `${g()??""} aw-1ou2cig`), M(c, "nav-link", !0), O(G, n())
            }), m(d, c)
        }), s(l), s(e), m(i, e)
    });
    var T = r(r(H, !0)),
        z = t(T);
    Y(z, () => v.children), s(T);
    var W = r(r(T, !0)),
        F = t(W),
        J = t(F);
    B(J, 65, () => j, E, (i, e, l) => {
        let d = () => a(a(e)).name,
            p = () => a(a(e)).href;
        var u = me(),
            n = K(u),
            o = t(n);
        s(n);
        var g = r(r(n, !0));
        R(g, () => a(l) !== j.length - 1, c => {
            var G = pe();
            m(c, G)
        }), h(() => {
            I(n, "href", p()), O(o, d())
        }), m(i, u)
    }), s(F), s(W), s(y), m(b, y), V()
}
$(["click"]);
export {
    Re as component
};