import {
    a as l,
    t as v,
    r as o,
    b as p,
    f as _,
    s as m
} from "../chunks/disclose-version.91b4a1e6.js";
import {
    p as u,
    h as x,
    c as $
} from "../chunks/runtime.712ce216.js";
import {
    s as i
} from "../chunks/render.95e1ab5e.js";
import {
    i as d
} from "../chunks/lifecycle.b2515c68.js";
import {
    s as b,
    a as E
} from "../chunks/store.c23b96c9.js";
import {
    p as j
} from "../chunks/stores.ec90b28b.js";
var k = v("<h1> </h1> <p> </p>", 1);

function C(f, n) {
    u(n, !1);
    const c = b(),
        s = () => E(j, "$page", c);
    d();
    var r = k(),
        t = _(r),
        g = p(t);
    o(t);
    var a = m(m(t, !0)),
        h = p(a);
    o(a), x(() => {
        var e;
        i(g, s().status), i(h, (e = s().error) == null ? void 0 : e.message)
    }), l(f, r), $()
}
export {
    C as component
};