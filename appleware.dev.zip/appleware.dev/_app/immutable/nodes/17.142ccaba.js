import {
    c as W,
    a as e,
    r as t,
    n as d,
    b as o,
    s as a,
    f as x,
    d as ie,
    t as Q,
    e as te
} from "../chunks/disclose-version.91b4a1e6.js";
import {
    p as ee,
    k as le,
    h as F,
    c as ae,
    w as ue,
    x as he,
    i as B,
    g as m,
    m as X,
    s as J
} from "../chunks/runtime.712ce216.js";
import {
    s as G
} from "../chunks/render.95e1ab5e.js";
import {
    i as v
} from "../chunks/if.c692dc35.js";
import {
    e as oe,
    i as me
} from "../chunks/each.14627b3c.js";
import {
    c as fe
} from "../chunks/svelte-component.351a274c.js";
import {
    a as ne,
    s as ge
} from "../chunks/attributes.0fe580a6.js";
import {
    t as _e
} from "../chunks/class.cca9bd46.js";
import {
    d as we
} from "../chunks/svelte-head.5f7b6b5a.js";
import {
    t as se,
    f as ye,
    s as be
} from "../chunks/index.aac95cae.js";
import {
    i as re
} from "../chunks/lifecycle.b2515c68.js";
import {
    g as xe
} from "../chunks/navigation.a85db85e.js";
import {
    P as Ae
} from "../chunks/PageMeta.d777c4a0.js";
import {
    c as We
} from "../chunks/Modal.cbdcfdc4.js";
import {
    s as de,
    d as ce
} from "../chunks/misc.9c34d7d8.js";
import {
    l as K,
    p as L
} from "../chunks/props.a974af4b.js";
import {
    D as $e
} from "../chunks/DownloadSimple.073a6a60.js";
import {
    S as Me
} from "../chunks/SvelteMarkdown.4b8552a7.js";
const ke = "" + new URL("../assets/ingame.295683cd.jpg",
    import.meta.url).href;
var Ce = d('<path d="M216.49,104.49l-80,80a12,12,0,0,1-17,0l-80-80a12,12,0,0,1,17-17L128,159l71.51-71.52a12,12,0,0,1,17,17Z"></path>'),
    Ze = d('<path d="M208,96l-80,80L48,96Z" opacity="0.2"></path><path d="M215.39,92.94A8,8,0,0,0,208,88H48a8,8,0,0,0-5.66,13.66l80,80a8,8,0,0,0,11.32,0l80-80A8,8,0,0,0,215.39,92.94ZM128,164.69,67.31,104H188.69Z"></path>', 1),
    qe = d('<path d="M213.66,101.66l-80,80a8,8,0,0,1-11.32,0l-80-80A8,8,0,0,1,48,88H208a8,8,0,0,1,5.66,13.66Z"></path>'),
    ze = d('<path d="M212.24,100.24l-80,80a6,6,0,0,1-8.48,0l-80-80a6,6,0,0,1,8.48-8.48L128,167.51l75.76-75.75a6,6,0,0,1,8.48,8.48Z"></path>'),
    Le = d('<path d="M213.66,101.66l-80,80a8,8,0,0,1-11.32,0l-80-80A8,8,0,0,1,53.66,90.34L128,164.69l74.34-74.35a8,8,0,0,1,11.32,11.32Z"></path>'),
    Se = d('<path d="M210.83,98.83l-80,80a4,4,0,0,1-5.66,0l-80-80a4,4,0,0,1,5.66-5.66L128,170.34l77.17-77.17a4,4,0,1,1,5.66,5.66Z"></path>'),
    De = d('<svg><!><rect width="256" height="256" fill="none"></rect><!></svg>');

function Ie(S, r) {
    const f = K(r, ["children", "$$slots", "$$events", "$$legacy"]),
        E = K(f, ["weight", "color", "size", "mirrored"]);
    ee(r, !1);
    const {
        weight: q,
        color: $,
        size: N,
        mirrored: D,
        ...V
    } = le("iconCtx") || {};
    let s = L(r, "weight", 0, q ? ? "regular"),
        T = L(r, "color", 0, $ ? ? "currentColor"),
        M = L(r, "size", 0, N ? ? "1em"),
        I = L(r, "mirrored", 0, D || !1);
    re();
    var g = De();
    let z;
    var O = o(g);
    de(O, ce(r), {}, null);
    var R = a(O),
        P = a(R);
    v(P, () => s() === "bold", k => {
        var p = Ce();
        e(k, p)
    }, k => {
        var p = W(),
            U = x(p);
        v(U, () => s() === "duotone", C => {
            var u = Ze();
            e(C, u)
        }, C => {
            var u = W(),
                j = x(u);
            v(j, () => s() === "fill", A => {
                var _ = qe();
                e(A, _)
            }, A => {
                var _ = W(),
                    Z = x(_);
                v(Z, () => s() === "light", l => {
                    var w = ze();
                    e(l, w)
                }, l => {
                    var w = W(),
                        n = x(w);
                    v(n, () => s() === "regular", c => {
                        var i = Le();
                        e(c, i)
                    }, c => {
                        var i = W(),
                            y = x(i);
                        v(y, () => s() === "thin", h => {
                            var b = Se();
                            e(h, b)
                        }, h => {
                            var b = ie();
                            F(() => G(b, (console.error('Unsupported icon weight. Choose from "thin", "light", "regular", "bold", "fill", or "duotone".'), ""))), e(h, b)
                        }, !0), e(c, i)
                    }, !0), e(l, w)
                }, !0), e(A, _)
            }, !0), e(C, u)
        }, !0), e(k, p)
    }), t(g), F(() => z = ne(g, z, {
        xmlns: "http://www.w3.org/2000/svg",
        width: M(),
        height: M(),
        fill: T(),
        transform: I() ? "scale(-1, 1)" : void 0,
        viewBox: "0 0 256 256",
        ...V,
        ...E
    }, !1, "")), e(S, g), ae()
}
var Oe = d('<path d="M184.49,136.49l-80,80a12,12,0,0,1-17-17L159,128,87.51,56.49a12,12,0,1,1,17-17l80,80A12,12,0,0,1,184.49,136.49Z"></path>'),
    Re = d('<path d="M176,128,96,208V48Z" opacity="0.2"></path><path d="M181.66,122.34l-80-80A8,8,0,0,0,88,48V208a8,8,0,0,0,13.66,5.66l80-80A8,8,0,0,0,181.66,122.34ZM104,188.69V67.31L164.69,128Z"></path>', 1),
    Pe = d('<path d="M181.66,133.66l-80,80A8,8,0,0,1,88,208V48a8,8,0,0,1,13.66-5.66l80,80A8,8,0,0,1,181.66,133.66Z"></path>'),
    Ue = d('<path d="M180.24,132.24l-80,80a6,6,0,0,1-8.48-8.48L167.51,128,91.76,52.24a6,6,0,0,1,8.48-8.48l80,80A6,6,0,0,1,180.24,132.24Z"></path>'),
    He = d('<path d="M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z"></path>'),
    Be = d('<path d="M178.83,130.83l-80,80a4,4,0,0,1-5.66-5.66L170.34,128,93.17,50.83a4,4,0,0,1,5.66-5.66l80,80A4,4,0,0,1,178.83,130.83Z"></path>'),
    Fe = d('<svg><!><rect width="256" height="256" fill="none"></rect><!></svg>');

function Ve(S, r) {
    const f = K(r, ["children", "$$slots", "$$events", "$$legacy"]),
        E = K(f, ["weight", "color", "size", "mirrored"]);
    ee(r, !1);
    const {
        weight: q,
        color: $,
        size: N,
        mirrored: D,
        ...V
    } = le("iconCtx") || {};
    let s = L(r, "weight", 0, q ? ? "regular"),
        T = L(r, "color", 0, $ ? ? "currentColor"),
        M = L(r, "size", 0, N ? ? "1em"),
        I = L(r, "mirrored", 0, D || !1);
    re();
    var g = Fe();
    let z;
    var O = o(g);
    de(O, ce(r), {}, null);
    var R = a(O),
        P = a(R);
    v(P, () => s() === "bold", k => {
        var p = Oe();
        e(k, p)
    }, k => {
        var p = W(),
            U = x(p);
        v(U, () => s() === "duotone", C => {
            var u = Re();
            e(C, u)
        }, C => {
            var u = W(),
                j = x(u);
            v(j, () => s() === "fill", A => {
                var _ = Pe();
                e(A, _)
            }, A => {
                var _ = W(),
                    Z = x(_);
                v(Z, () => s() === "light", l => {
                    var w = Ue();
                    e(l, w)
                }, l => {
                    var w = W(),
                        n = x(w);
                    v(n, () => s() === "regular", c => {
                        var i = He();
                        e(c, i)
                    }, c => {
                        var i = W(),
                            y = x(i);
                        v(y, () => s() === "thin", h => {
                            var b = Be();
                            e(h, b)
                        }, h => {
                            var b = ie();
                            F(() => G(b, (console.error('Unsupported icon weight. Choose from "thin", "light", "regular", "bold", "fill", or "duotone".'), ""))), e(h, b)
                        }, !0), e(c, i)
                    }, !0), e(l, w)
                }, !0), e(A, _)
            }, !0), e(C, u)
        }, !0), e(k, p)
    }), t(g), F(() => z = ne(g, z, {
        xmlns: "http://www.w3.org/2000/svg",
        width: M(),
        height: M(),
        fill: T(),
        transform: I() ? "scale(-1, 1)" : void 0,
        viewBox: "0 0 256 256",
        ...V,
        ...E
    }, !1, "")), e(S, g), ae()
}
var Te = async (S, r, f) => {
        await r("Are you sure you want to leave this page?") && f("/manage")
    },
    je = Q('<div class="card"><div class="card-header"> </div> <div class="card-body text-lg"> </div></div>'),
    Ee = (S, r, f) => {
        J(r, m(r) === f() ? "" : f())
    },
    Ne = Q('<div class="faq-answer markdown-body aw-1rl0rt6"><!></div>'),
    Xe = Q('<div class="faq aw-1rl0rt6"><div class="faq-question aw-1rl0rt6"><!> </div> <!></div>'),
    Ge = Q(`<!> <div class="flex flex-col gap-2"><div class="card flex flex-col items-center justify-center !py-8 px-4 gap-4"><div class="text-center"><div class="highlight aw-1rl0rt6" aria-hidden="true">Development Redefined.</div> <div class="text-xl text-neutral-300 text-center">Apple-Ware is the leading free-to-use iOS based mobile development tool
        for ROBLOX.</div></div> <a href="/download" class="btn uppercase btn-primary text-lg font-semibold flex items-center gap-2"><!> Download Now</a></div> <div class="grid grid-rows-3 sm:grid-rows-1 sm:grid-cols-3 gap-2"></div> <div class="card"><div class="card card-body"><span class="font-bold">NOTE:</span> <span class="font-bold text-fuchsia-500">appleware.dev</span> is our <b>only</b> offical website. Please be cautious and avoid downloading from other/unknown
      sources.</div></div> <div class="flex flex-col lg:flex-row gap-4"><div class="card grow"><div class="card-header">Frequently Asked Questions</div> <div class="card-body !p-0"><div class="faq-container aw-1rl0rt6"></div></div></div> <div class="flex flex-col shrink-0"><img alt="Apple-Ware In-Game" class="w-full rounded-md"> <p class="text-neutral-300">Image of Apple-Ware in use</p></div></div></div>`, 1);

function ha(S, r) {
    ee(r, !1);
    let f = [{
            header: "Reliable",
            body: "Apple-Ware is the most reliable iOS based development tool for ROBLOX."
        }, {
            header: "Free Forever",
            body: "Apple-Ware is free to use and will always be free to use."
        }, {
            header: "Easy To Use",
            body: "Apple-Ware is easy to use and has a simple user interface."
        }, {
            header: "Safe",
            body: "Apple-Ware is completely undetected and safe to use."
        }, {
            header: "Large Community",
            body: "Apple-Ware has a large active community of users and developers."
        }, {
            header: "Regular Updates",
            body: "Apple-Ware is updated regularly to ensure the best experience."
        }],
        E = X([{
            question: "What is Apple-Ware?",
            answer: "AppleWare stands as the premier iOS development tool utilized by developers across a wide spectrum of skill levels. With AppleWare, developers gain the ability to create, customize, and execute Lua scripts for diverse purposes, ranging from game functionality testing to enhancing game security."
        }, {
            question: "How to install AppleWare?",
            answer: "AppleWare provides multiple installation methods, each accompanied by clear written instructions to facilitate a seamless installation process. Choose the method that best suits your preferences, and follow the step-by-step instructions provided. You can find these installation instructions at the bottom of our [Downloads Page](https://appleware.dev/download), provided an available download is offered."
        }, {
            question: "Is AppleWare free?",
            answer: "AppleWare remains committed to being a free-to-use tool accessible to all users. We provide an uninterrupted supply of 24-hour keys. To obtain one, simply engage with our Key System, which involves viewing a curated selection of advertisements—no surveys or personal information required. Use the uniquely generated key to activate your AppleWare license. For users seeking an ad-free experience or extended access, purchasing options are available through our [Community Discord](https://discord.gg/appleware)."
        }, {
            question: "Where can I find help?",
            answer: "Our [Community Discord](https://discord.gg/appleware) is staffed by a dedicated team ready to assist in any way possible. We kindly remind you to explore our Discord channels specifically dedicated to AppleWare support after reviewing our community rules and verifying your account."
        }, {
            question: "Is AppleWare safe?",
            answer: "At AppleWare, our developers are renowned for their trustworthiness and reputation within their respective fields. We prioritize the utmost safety for our users by implementing rigorous processes and multiple security measures. Whether you’re using our app or engaging with our community platforms, safeguarding your information remains our top priority."
        }]),
        q = X(),
        $ = X(0);
    const N = X(() => f.slice(m($), m($) + 3));
    let D = X();
    ue(() => (m(D), m($)), () => {
        clearInterval(m(D)), J(D, setInterval(() => {
            J($, (m($) + 3) % f.length)
        }, 1e4))
    }), he(), re();
    var V = Ge(),
        s = x(V);
    Ae(s, {
        title: "Home",
        $$legacy: !0
    });
    var T = a(a(s, !0)),
        M = o(T),
        I = o(M),
        g = o(I);
    g.__dblclick = [Te, We, xe], t(I);
    var z = a(a(I, !0)),
        O = o(z);
    $e(O, {
        $$legacy: !0
    }), te(), t(z), t(M);
    var R = a(a(M, !0));
    oe(R, 13, () => m(N)(), (Z, l) => B(Z).header, (Z, l, w) => {
        var n = je();
        se(1, n, () => ye, () => ({
            y: 10,
            duration: 250
        }));
        var c = o(n),
            i = o(c);
        t(c);
        var y = a(a(c, !0)),
            h = o(y);
        t(y), t(n), F(() => {
            G(i, B(l).header), G(h, B(l).body)
        }), e(Z, n)
    }), t(R);
    var P = a(a(R, !0)),
        k = o(P);
    te(), t(k), t(P);
    var p = a(a(P, !0)),
        U = o(p),
        C = o(U),
        u = a(a(C, !0)),
        j = o(u);
    oe(j, 9, () => m(E), me, (Z, l, w) => {
        let n = () => B(B(l)).question,
            c = () => B(B(l)).answer;
        var i = Xe(),
            y = o(i);
        y.__click = [Ee, q, n];
        var h = o(y);
        fe(h, () => m(q) === n() ? Ie : Ve, (Y, H) => {
            H(Y, {
                $$legacy: !0
            })
        });
        var b = a(h, !0);
        t(y);
        var ve = a(a(y, !0));
        v(ve, () => m(q) === n(), Y => {
            var H = Ne();
            se(3, H, () => be);
            var pe = o(H);
            Me(pe, {
                get source() {
                    return c()
                },
                $$legacy: !0
            }), t(H), F(() => _e(H, "active", m(q) === n())), e(Y, H)
        }), t(i), F(() => G(b, ` ${n()??""}`)), e(Z, i)
    }), t(j), t(u), t(U);
    var A = a(a(U, !0)),
        _ = o(A);
    ge(_, "src", ke), t(A), t(p), t(T), e(S, V), ae()
}
we(["dblclick", "click"]);
export {
    ha as component
};