import {
    a as d,
    t as _,
    $ as I,
    r as l,
    b as f,
    c as L,
    s as e,
    f as b
} from "../chunks/disclose-version.91b4a1e6.js";
import {
    p as S,
    b as J,
    c as C,
    g as u,
    i as o,
    j as K,
    h as T
} from "../chunks/runtime.712ce216.js";
import {
    s as N
} from "../chunks/snippet.affc9ce4.js";
import {
    d as q,
    e as O
} from "../chunks/svelte-head.5f7b6b5a.js";
import {
    i as x
} from "../chunks/if.c692dc35.js";
import {
    e as z
} from "../chunks/each.14627b3c.js";
import {
    c as P
} from "../chunks/svelte-component.351a274c.js";
import {
    s as A,
    a as B
} from "../chunks/store.c23b96c9.js";
import {
    m as Q
} from "../chunks/Modal.cbdcfdc4.js";
import {
    s as j
} from "../chunks/render.95e1ab5e.js";
import {
    s as R
} from "../chunks/attributes.0fe580a6.js";
import {
    t as E
} from "../chunks/class.cca9bd46.js";
import {
    t as U,
    f as V
} from "../chunks/index.aac95cae.js";
import {
    i as W
} from "../chunks/lifecycle.b2515c68.js";
import {
    t as X
} from "../chunks/Toast.015eb9d1.js";
var Y = (c, s) => {
        u(s).dismiss()
    },
    Z = _('<div class="modal-backdrop aw-1its8n" aria-hidden="true"></div>'),
    tt = _('<div class="modal-container"><!> <!></div>');

function at(c, s) {
    S(s, !0);
    const m = A(),
        i = () => B(Q, "$modalStore", m);
    J(() => {
        document.body.classList.toggle("overflow-y-hidden", u(a) !== void 0)
    });
    let a = K(() => i()[i().length - 1]);
    var v = tt();
    O("keydown", I, r => {
        r.key === "Escape" && u(a) && u(a).dismiss()
    }, !1);
    var $ = f(v);
    z($, 69, i, (r, t) => o(r).id, (r, t, D) => {
        var n = L(),
            g = b(n);
        P(g, () => o(t).config.component, (y, w) => {
            w(y, {
                get modal() {
                    return o(t)
                }
            })
        }), d(r, n)
    });
    var p = e(e($, !0));
    x(p, () => u(a), r => {
        var t = Z();
        t.__click = [Y, a], d(r, t)
    }), l(v), d(c, v), C()
}
q(["click"]);
var rt = (c, s) => o(s).dismiss(),
    ot = _('<div class="toast-title aw-13ufr2c"> </div>'),
    st = _('<div class="toast aw-13ufr2c" aria-hidden="true"><div class="toast-body aw-13ufr2c"><!> <div class="toast-message"> </div></div> <div class="toast-progress-container aw-13ufr2c"><div class="toast-progress aw-13ufr2c"></div></div></div>'),
    et = _('<div class="toast-container aw-13ufr2c"></div>');

function it(c, s) {
    S(s, !1);
    const m = A(),
        i = () => B(X, "$toastStore", m);
    W();
    var a = L(),
        v = b(a);
    x(v, () => i().length > 0, $ => {
        var p = et();
        z(p, 13, i, (r, t) => o(r).id, (r, t, D) => {
            var n = st();
            U(1, n, () => V, () => ({
                x: 100,
                duration: 200
            })), n.__click = [rt, t];
            var g = f(n),
                y = f(g);
            x(y, () => o(t).config.title, G => {
                var k = ot(),
                    H = f(k);
                l(k), T(() => j(H, o(t).config.title)), d(G, k)
            });
            var w = e(e(y, !0)),
                F = f(w);
            l(w), l(g);
            var M = e(e(g, !0)),
                h = f(M);
            l(M), l(n), T(() => {
                j(F, o(t).config.message), R(h, "style", `width: ${o(t).progress??""}%`), E(h, "toast-success", o(t).config.type === "success"), E(h, "toast-error", o(t).config.type === "error")
            }), d(r, n)
        }), l(p), d($, p)
    }), d(c, a), C()
}
q(["click"]);
var nt = _("<!> <!> <!>", 1);

function xt(c, s) {
    S(s, !0);
    var m = nt(),
        i = b(m);
    N(i, () => s.children);
    var a = e(e(i, !0));
    at(a, {});
    var v = e(e(a, !0));
    it(v, {}), d(c, m), C()
}
export {
    xt as component
};