import {
    d as e
} from "./singletons.9d8d5935.js";
const r = () => {
        const s = e;
        return {
            page: {
                subscribe: s.page.subscribe
            },
            navigating: {
                subscribe: s.navigating.subscribe
            },
            updated: s.updated
        }
    },
    b = {
        subscribe(s) {
            return r().page.subscribe(s)
        }
    };
export {
    b as p
};