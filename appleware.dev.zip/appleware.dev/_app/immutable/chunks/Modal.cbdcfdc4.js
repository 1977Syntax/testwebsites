import {
    a,
    n as L,
    b as _,
    c as b,
    s as h,
    f as p,
    d as O,
    r as u,
    t as S
} from "./disclose-version.91b4a1e6.js";
import {
    d as E,
    e as at
} from "./svelte-head.5f7b6b5a.js";
import {
    p as G,
    k as rt,
    h as C,
    c as I,
    g as ot,
    j as et
} from "./runtime.712ce216.js";
import {
    s as J
} from "./render.95e1ab5e.js";
import {
    i as f
} from "./if.c692dc35.js";
import {
    s as q
} from "./snippet.affc9ce4.js";
import {
    t as st
} from "./class.cca9bd46.js";
import {
    s as it,
    a as nt
} from "./store.c23b96c9.js";
import {
    i as Q
} from "./lifecycle.b2515c68.js";
import {
    l as K,
    p as M
} from "./props.a974af4b.js";
import {
    w as lt
} from "./index.06d71b23.js";
import {
    s as dt,
    d as mt
} from "./misc.9c34d7d8.js";
import {
    a as vt
} from "./attributes.0fe580a6.js";
var ct = L('<path d="M208.49,191.51a12,12,0,0,1-17,17L128,145,64.49,208.49a12,12,0,0,1-17-17L111,128,47.51,64.49a12,12,0,0,1,17-17L128,111l63.51-63.52a12,12,0,0,1,17,17L145,128Z"></path>'),
    _t = L('<path d="M216,56V200a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V56A16,16,0,0,1,56,40H200A16,16,0,0,1,216,56Z" opacity="0.2"></path><path d="M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z"></path>', 1),
    ut = L('<path d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM181.66,170.34a8,8,0,0,1-11.32,11.32L128,139.31,85.66,181.66a8,8,0,0,1-11.32-11.32L116.69,128,74.34,85.66A8,8,0,0,1,85.66,74.34L128,116.69l42.34-42.35a8,8,0,0,1,11.32,11.32L139.31,128Z"></path>'),
    ft = L('<path d="M204.24,195.76a6,6,0,1,1-8.48,8.48L128,136.49,60.24,204.24a6,6,0,0,1-8.48-8.48L119.51,128,51.76,60.24a6,6,0,0,1,8.48-8.48L128,119.51l67.76-67.75a6,6,0,0,1,8.48,8.48L136.49,128Z"></path>'),
    ht = L('<path d="M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z"></path>'),
    pt = L('<path d="M202.83,197.17a4,4,0,0,1-5.66,5.66L128,133.66,58.83,202.83a4,4,0,0,1-5.66-5.66L122.34,128,53.17,58.83a4,4,0,0,1,5.66-5.66L128,122.34l69.17-69.17a4,4,0,1,1,5.66,5.66L133.66,128Z"></path>'),
    gt = L('<svg><!><rect width="256" height="256" fill="none"></rect><!></svg>');

function bt(r, t) {
    const n = K(t, ["children", "$$slots", "$$events", "$$legacy"]),
        i = K(n, ["weight", "color", "size", "mirrored"]);
    G(t, !1);
    const {
        weight: s,
        color: l,
        size: d,
        mirrored: m,
        ...v
    } = rt("iconCtx") || {};
    let c = M(t, "weight", 0, s ? ? "regular"),
        y = M(t, "color", 0, l ? ? "currentColor"),
        k = M(t, "size", 0, d ? ? "1em"),
        x = M(t, "mirrored", 0, m || !1);
    Q();
    var w = gt();
    let Z;
    var e = _(w);
    dt(e, mt(t), {}, null);
    var o = h(e),
        g = h(o);
    f(g, () => c() === "bold", j => {
        var A = ct();
        a(j, A)
    }, j => {
        var A = b(),
            R = p(A);
        f(R, () => c() === "duotone", B => {
            var z = _t();
            a(B, z)
        }, B => {
            var z = b(),
                T = p(z);
            f(T, () => c() === "fill", N => {
                var H = ut();
                a(N, H)
            }, N => {
                var H = b(),
                    Y = p(H);
                f(Y, () => c() === "light", U => {
                    var V = ft();
                    a(U, V)
                }, U => {
                    var V = b(),
                        $ = p(V);
                    f($, () => c() === "regular", W => {
                        var D = ht();
                        a(W, D)
                    }, W => {
                        var D = b(),
                            tt = p(D);
                        f(tt, () => c() === "thin", X => {
                            var F = pt();
                            a(X, F)
                        }, X => {
                            var F = O();
                            C(() => J(F, (console.error('Unsupported icon weight. Choose from "thin", "light", "regular", "bold", "fill", or "duotone".'), ""))), a(X, F)
                        }, !0), a(W, D)
                    }, !0), a(U, V)
                }, !0), a(N, H)
            }, !0), a(B, z)
        }, !0), a(j, A)
    }), u(w), C(() => Z = vt(w, Z, {
        xmlns: "http://www.w3.org/2000/svg",
        width: k(),
        height: k(),
        fill: y(),
        transform: x() ? "scale(-1, 1)" : void 0,
        viewBox: "0 0 256 256",
        ...v,
        ...i
    }, !1, "")), a(r, w), I()
}
var Lt = (r, t) => t.modal.dismiss(),
    wt = S("<p>No content</p>"),
    yt = S('<div class="card-footer controls"><!></div>'),
    xt = S('<div class="modal aw-1p4r000"><form><div class="card aw-1p4r000"><div class="card-header aw-1p4r000"><!> <button type="button" class="ml-8 close aw-1p4r000"><!></button></div> <div class="card-body aw-1p4r000"><!></div> <!></div></form></div>');

function Mt(r, t) {
    G(t, !0);
    const n = it(),
        i = () => nt(P, "$modalStore", n);
    let s = et(() => i()[i().length - 1] == t.modal);
    var l = xt(),
        d = _(l),
        m = _(d),
        v = _(m),
        c = _(v);
    f(c, () => t.header, e => {
        var o = b(),
            g = p(o);
        q(g, () => t.header), a(e, o)
    }, e => {
        var o = O();
        C(() => J(o, t.title || "Modal")), a(e, o)
    });
    var y = h(h(c, !0));
    y.__click = [Lt, t];
    var k = _(y);
    bt(k, {}), u(y), u(v);
    var x = h(h(v, !0)),
        w = _(x);
    f(w, () => t.body, e => {
        var o = b(),
            g = p(o);
        q(g, () => t.body), a(e, o)
    }, e => {
        var o = wt();
        a(e, o)
    }), u(x);
    var Z = h(h(x, !0));
    f(Z, () => t.footer, e => {
        var o = yt(),
            g = _(o);
        q(g, () => t.footer), u(o), a(e, o)
    }), u(m), u(d), u(l), C(() => st(l, "!hidden", !ot(s))), at("submit", d, e => {
        e.preventDefault(), t.onFormSubmit && t.onFormSubmit(e)
    }, !1), a(r, l), I()
}
E(["click"]);
E(["click"]);
var Ct = S("<p> </p>"),
    St = (r, t) => t().dismiss(),
    kt = S('<button class="btn btn-secondary" type="button">Cancel</button> <button class="btn btn-primary" type="submit">Confirm</button>', 1);

function Zt(r, t) {
    G(t, !1);
    const n = d => {
            var m = Ct(),
                v = _(m);
            u(m), C(() => J(v, s().config.props.message)), a(d, m)
        },
        i = d => {
            var m = kt(),
                v = p(m);
            v.__click = [St, s], a(d, m)
        };
    let s = M(t, "modal");
    const l = async d => {
        s().submit()
    };
    Q(), Mt(r, {
        onFormSubmit: l,
        get modal() {
            return s()
        },
        body: n,
        footer: i,
        get title() {
            return s().config.props.title
        },
        $$legacy: !0
    }), I()
}
E(["click"]);
const P = lt([]),
    At = r => {
        const t = Math.random().toString(36).substring(2),
            n = {
                id: t,
                config: r,
                dismiss: () => {
                    var i;
                    P.update(s => s.filter(l => l.id !== t)), (i = r.onDismiss) == null || i.call(r)
                },
                submit: (...i) => {
                    var s;
                    P.update(l => l.filter(d => d.id !== t)), (s = r.onSubmit) == null || s.call(r, ...i)
                }
            };
        return P.update(i => [...i, n]), console.log(n), n
    },
    Et = r => new Promise(t => {
        const n = At({
            props: {
                message: r,
                title: "Confirm"
            },
            component: Zt
        });
        n.config.onSubmit = () => {
            t(!0)
        }, n.config.onDismiss = () => {
            t(!1)
        }
    });
export {
    Zt as C, Mt as M, At as a, Et as c, P as m
};