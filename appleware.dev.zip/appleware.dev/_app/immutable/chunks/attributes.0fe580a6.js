import {
    h as n,
    B,
    I as C,
    J as I,
    K as P
} from "./disclose-version.91b4a1e6.js";
import {
    q as $,
    a1 as D,
    a2 as K,
    K as w,
    a3 as M
} from "./runtime.712ce216.js";
import {
    f as E,
    d as G
} from "./svelte-head.5f7b6b5a.js";

function J(s, t) {
    if (t) {
        const r = document.body;
        s.autofocus = !0, $(() => {
            document.activeElement === r && s.focus()
        })
    }
}

function H(s) {
    n && s.firstChild !== null && B(s)
}
let L = !1;

function R() {
    L || (L = !0, document.addEventListener("reset", s => {
        Promise.resolve().then(() => {
            var t;
            if (!s.defaultPrevented)
                for (const r of s.target.elements)(t = r.__on_r) == null || t.call(r)
        })
    }, {
        capture: !0
    }))
}

function Q(s) {
    if (n) {
        var t = !1,
            r = () => {
                if (!t) {
                    if (t = !0, s.hasAttribute("value")) {
                        var a = s.value;
                        d(s, "value", null), s.value = a
                    }
                    if (s.hasAttribute("checked")) {
                        var c = s.checked;
                        d(s, "checked", null), s.checked = c
                    }
                }
            };
        s.__on_r = r, K(r), R()
    }
}

function d(s, t, r) {
    r = r == null ? null : r + "";
    var a = s.__attributes ? ? (s.__attributes = {});
    n && (a[t] = s.getAttribute(t), t === "src" || t === "href" || t === "srcset") || a[t] !== (a[t] = r) && (t === "loading" && (s[D] = r), r === null ? s.removeAttribute(t) : s.setAttribute(t, r))
}

function U(s, t, r, a, c) {
    var h = c.length !== 0,
        f = t || {},
        O = s.tagName === "OPTION";
    for (var g in t) g in r || (r[g] = null);
    h && !r.class && (r.class = "");
    var v = N.get(s.nodeName);
    v || N.set(s.nodeName, v = Y(s));
    var T = s.__attributes ? ? (s.__attributes = {}),
        A = [];
    for (const i in r) {
        let e = r[i];
        if (O && i === "value" && e == null) {
            s.value = s.__value = "", f[i] = e;
            continue
        }
        var y = f[i];
        if (e !== y) {
            f[i] = e;
            var b = i[0] + i[1];
            if (b !== "$$")
                if (b === "on") {
                    const _ = {},
                        l = "$$" + i;
                    let u = i.slice(2);
                    var k = P.includes(u);
                    if (C(u) && (u = u.slice(0, -7), _.capture = !0), !k && y) {
                        if (e != null) continue;
                        s.removeEventListener(u, f[l], _), f[l] = null
                    }
                    if (e != null)
                        if (k) s[`__${u}`] = e, G([u]);
                        else {
                            let p = function(q) {
                                f[i].call(this, q)
                            };
                            t ? f[l] = E(u, s, p, _) : A.push([i, e, () => f[l] = E(u, s, p, _)])
                        }
                } else if (e == null) T[i] = null, s.removeAttribute(i);
            else if (i === "style") s.style.cssText = e + "";
            else if (i === "autofocus") J(s, !!e);
            else if (i === "__value" || i === "value") s.value = s[i] = s.__value = e;
            else {
                var o = i;
                a && (o = o.toLowerCase(), o = I[o] || o), v.includes(o) ? n && (o === "src" || o === "href" || o === "srcset") || (s[o] = e) : typeof e != "function" && (h && o === "class" && (e && (e += " "), e += c), d(s, o, e))
            }
        }
    }
    return t || $(() => {
        if (s.isConnected)
            for (const [i, e, _] of A) f[i] === e && _()
    }), f
}
var S = ["width", "height"],
    N = new Map;

function Y(s) {
    for (var t = [], r, a = w(s); a.constructor.name !== "Element";) {
        r = M(a);
        for (var c in r) r[c].set && !S.includes(c) && t.push(c);
        a = w(a)
    }
    return t
}
export {
    U as a, H as b, R as c, Q as r, d as s
};