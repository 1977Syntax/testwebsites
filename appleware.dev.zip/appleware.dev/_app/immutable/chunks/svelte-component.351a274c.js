import {
    l as i,
    v as c,
    o as s
} from "./runtime.712ce216.js";
import {
    h as e,
    g as h,
    i as m
} from "./disclose-version.91b4a1e6.js";

function l(n, t, f) {
    e && h();
    var o = n,
        a, r;
    i(() => {
        a !== (a = t()) && (r && (s(r), r = null), a && (r = c(() => f(o, a))))
    }), e && (o = m)
}
export {
    l as c
};