import {
    w as n
} from "./index.06d71b23.js";
const a = n([]),
    u = e => {
        const s = Math.random().toString(36).substring(2),
            r = {
                id: s,
                config: {
                    duration: e.duration || 5e3,
                    title: e.type === "error" ? "Error" : e.type === "success" ? "Success" : "Info",
                    ...e
                },
                dismiss: () => {
                    a.update(t => t.filter(o => o.id !== s))
                },
                progress: 0,
                started: new Date
            };
        return a.update(t => [...t, r]), setTimeout(r.dismiss, r.config.duration), r
    }; {
    const e = () => {
        a.update(s => {
            const r = new Date;
            return s.map(t => {
                const o = r.getTime() - t.started.getTime();
                return t.progress = 100 - Math.min(100, o / (t.config.duration || 5e3) * 100), t
            })
        }), requestAnimationFrame(e)
    };
    requestAnimationFrame(e)
}
export {
    u as a, a as t
};