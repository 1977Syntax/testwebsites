import {
    Q as c,
    R as a,
    b as i,
    I as _,
    u as m
} from "./runtime.712ce216.js";

function d(n) {
    c === null && a(), c.l !== null ? v(c).m.push(n) : i(() => {
        const e = m(n);
        if (typeof e == "function") return e
    })
}

function p(n, e, {
    bubbles: o = !1,
    cancelable: s = !1
} = {}) {
    return new CustomEvent(n, {
        detail: e,
        bubbles: o,
        cancelable: s
    })
}

function x() {
    const n = c;
    return n === null && a(), (e, o, s) => {
        var r;
        const t = (r = n.s.$$events) == null ? void 0 : r[e];
        if (t) {
            const l = _(t) ? t.slice() : [t],
                u = p(e, o, s);
            for (const f of l) f.call(n.x, u);
            return !u.defaultPrevented
        }
        return !0
    }
}

function v(n) {
    var e = n.l;
    return e.u ? ? (e.u = {
        a: [],
        b: [],
        m: []
    })
}
export {
    x as c, d as o
};