import {
    a as t,
    t as r,
    b as f,
    r as g,
    s as a
} from "./disclose-version.91b4a1e6.js";
import {
    i as v
} from "./if.c692dc35.js";
import {
    s as _
} from "./attributes.0fe580a6.js";
import {
    p as d
} from "./props.a974af4b.js";
import {
    l as b
} from "./logo.02fb6bc2.js";
var x = r('<span class="kms aw-612n10">(ADMIN)</span>'),
    u = r('<a href="/" class="logo aw-612n10"><img alt="logo" class="w-8 h-8"> <span class="text-xl md:text-2xl tracking-wider font-semibold">Apple-Ware</span> <!></a>');

function A(e, l) {
    let p = d(l, "isKms", 0, !1);
    var s = u(),
        o = f(s);
    _(o, "src", b);
    var i = a(a(o, !0)),
        m = a(a(i, !0));
    v(m, p, n => {
        var c = x();
        t(n, c)
    }), g(s), t(e, s)
}
export {
    A as L
};