import {
    h as t
} from "./disclose-version.91b4a1e6.js";

function n(s, e) {
    var l = s.__className,
        a = c(e);
    t && s.className === a ? s.__className = a : (l !== a || t && s.className !== a) && (e == null ? s.removeAttribute("class") : s.className = a, s.__className = a)
}

function c(s) {
    return s ? ? ""
}

function r(s, e, l) {
    l ? s.classList.add(e) : s.classList.remove(e)
}
export {
    n as s, r as t
};