import {
    a,
    n as r,
    b as J,
    c as s,
    s as L,
    f as i,
    d as K,
    r as N
} from "./disclose-version.91b4a1e6.js";
import {
    p as O,
    k as Q,
    h as M,
    c as R
} from "./runtime.712ce216.js";
import {
    s as T
} from "./render.95e1ab5e.js";
import {
    i as o
} from "./if.c692dc35.js";
import {
    s as X,
    d as Y
} from "./misc.9c34d7d8.js";
import {
    a as $
} from "./attributes.0fe580a6.js";
import {
    i as a0
} from "./lifecycle.b2515c68.js";
import {
    l as b,
    p as c
} from "./props.a974af4b.js";
var t0 = r('<path d="M228,144v64a12,12,0,0,1-12,12H40a12,12,0,0,1-12-12V144a12,12,0,0,1,24,0v52H204V144a12,12,0,0,1,24,0Zm-108.49,8.49a12,12,0,0,0,17,0l40-40a12,12,0,0,0-17-17L140,115V32a12,12,0,0,0-24,0v83L96.49,95.51a12,12,0,0,0-17,17Z"></path>'),
    r0 = r('<path d="M216,48V208H40V48A16,16,0,0,1,56,32H200A16,16,0,0,1,216,48Z" opacity="0.2"></path><path d="M224,144v64a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V144a8,8,0,0,1,16,0v56H208V144a8,8,0,0,1,16,0Zm-101.66,5.66a8,8,0,0,0,11.32,0l40-40a8,8,0,0,0-11.32-11.32L136,124.69V32a8,8,0,0,0-16,0v92.69L93.66,98.34a8,8,0,0,0-11.32,11.32Z"></path>', 1),
    e0 = r('<path d="M224,144v64a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V144a8,8,0,0,1,16,0v56H208V144a8,8,0,0,1,16,0Zm-101.66,5.66a8,8,0,0,0,11.32,0l40-40A8,8,0,0,0,168,96H136V32a8,8,0,0,0-16,0V96H88a8,8,0,0,0-5.66,13.66Z"></path>'),
    o0 = r('<path d="M222,144v64a6,6,0,0,1-6,6H40a6,6,0,0,1-6-6V144a6,6,0,0,1,12,0v58H210V144a6,6,0,0,1,12,0Zm-98.24,4.24a6,6,0,0,0,8.48,0l40-40a6,6,0,0,0-8.48-8.48L134,129.51V32a6,6,0,0,0-12,0v97.51L92.24,99.76a6,6,0,0,0-8.48,8.48Z"></path>'),
    s0 = r('<path d="M224,144v64a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V144a8,8,0,0,1,16,0v56H208V144a8,8,0,0,1,16,0Zm-101.66,5.66a8,8,0,0,0,11.32,0l40-40a8,8,0,0,0-11.32-11.32L136,124.69V32a8,8,0,0,0-16,0v92.69L93.66,98.34a8,8,0,0,0-11.32,11.32Z"></path>'),
    i0 = r('<path d="M220,144v64a4,4,0,0,1-4,4H40a4,4,0,0,1-4-4V144a4,4,0,0,1,8,0v60H212V144a4,4,0,0,1,8,0Zm-94.83,2.83a4,4,0,0,0,5.66,0l40-40a4,4,0,1,0-5.66-5.66L132,134.34V32a4,4,0,0,0-8,0V134.34L90.83,101.17a4,4,0,0,0-5.66,5.66Z"></path>'),
    l0 = r('<svg><!><rect width="256" height="256" fill="none"></rect><!></svg>');

function _0(z, t) {
    const C = b(t, ["children", "$$slots", "$$events", "$$legacy"]),
        y = b(C, ["weight", "color", "size", "mirrored"]);
    O(t, !1);
    const {
        weight: A,
        color: k,
        size: D,
        mirrored: S,
        ...B
    } = Q("iconCtx") || {};
    let e = c(t, "weight", 0, A ? ? "regular"),
        P = c(t, "color", 0, k ? ? "currentColor"),
        w = c(t, "size", 0, D ? ? "1em"),
        U = c(t, "mirrored", 0, S || !1);
    a0();
    var l = l0();
    let x;
    var Z = J(l);
    X(Z, Y(t), {}, null);
    var W = L(Z),
        j = L(W);
    o(j, () => e() === "bold", f => {
        var v = t0();
        a(f, v)
    }, f => {
        var v = s(),
            q = i(v);
        o(q, () => e() === "duotone", _ => {
            var n = r0();
            a(_, n)
        }, _ => {
            var n = s(),
                E = i(n);
            o(E, () => e() === "fill", g => {
                var h = e0();
                a(g, h)
            }, g => {
                var h = s(),
                    F = i(h);
                o(F, () => e() === "light", V => {
                    var m = o0();
                    a(V, m)
                }, V => {
                    var m = s(),
                        G = i(m);
                    o(G, () => e() === "regular", u => {
                        var d = s0();
                        a(u, d)
                    }, u => {
                        var d = s(),
                            I = i(d);
                        o(I, () => e() === "thin", H => {
                            var p = i0();
                            a(H, p)
                        }, H => {
                            var p = K();
                            M(() => T(p, (console.error('Unsupported icon weight. Choose from "thin", "light", "regular", "bold", "fill", or "duotone".'), ""))), a(H, p)
                        }, !0), a(u, d)
                    }, !0), a(V, m)
                }, !0), a(g, h)
            }, !0), a(_, n)
        }, !0), a(f, v)
    }), N(l), M(() => x = $(l, x, {
        xmlns: "http://www.w3.org/2000/svg",
        width: w(),
        height: w(),
        fill: P(),
        transform: U() ? "scale(-1, 1)" : void 0,
        viewBox: "0 0 256 256",
        ...B,
        ...y
    }, !1, "")), a(z, l), R()
}
export {
    _0 as D
};