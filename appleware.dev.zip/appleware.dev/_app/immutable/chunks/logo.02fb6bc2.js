const e = "" + new URL("../assets/logo.9e1ce39f.png",
    import.meta.url).href;
export {
    e as l
};