import {
    L as R,
    M as A,
    N as L,
    O as q
} from "./disclose-version.91b4a1e6.js";
import {
    f as N,
    J as b,
    a4 as j,
    a5 as K,
    a6 as M,
    g as l,
    s as T,
    a7 as U,
    u as g,
    j as O,
    N as C,
    m as Y,
    C as c
} from "./runtime.712ce216.js";
const $ = {
    get(e, r) {
        if (!e.exclude.includes(r)) return l(e.version), r in e.special ? e.special[r]() : e.props[r]
    },
    set(e, r, n) {
        return r in e.special || (e.special[r] = B({
            get [r]() {
                return e.props[r]
            }
        }, r, R)), e.special[r](n), U(e.version), !0
    },
    getOwnPropertyDescriptor(e, r) {
        if (!e.exclude.includes(r) && r in e.props) return {
            enumerable: !0,
            configurable: !0,
            value: e.props[r]
        }
    },
    has(e, r) {
        return e.exclude.includes(r) ? !1 : r in e.props
    },
    ownKeys(e) {
        return Reflect.ownKeys(e.props).filter(r => !e.exclude.includes(r))
    }
};

function V(e, r) {
    return new Proxy({
        props: e,
        exclude: r,
        special: {},
        version: N(0)
    }, $)
}
const z = {
    get(e, r) {
        let n = e.props.length;
        for (; n--;) {
            let u = e.props[n];
            if (c(u) && (u = u()), typeof u == "object" && u !== null && r in u) return u[r]
        }
    },
    getOwnPropertyDescriptor(e, r) {
        let n = e.props.length;
        for (; n--;) {
            let u = e.props[n];
            if (c(u) && (u = u()), typeof u == "object" && u !== null && r in u) return b(u, r)
        }
    },
    has(e, r) {
        for (let n of e.props)
            if (c(n) && (n = n()), n != null && r in n) return !0;
        return !1
    },
    ownKeys(e) {
        const r = [];
        for (let n of e.props) {
            c(n) && (n = n());
            for (const u in n) r.includes(u) || r.push(u)
        }
        return r
    }
};

function Z(...e) {
    return new Proxy({
        props: e
    }, z)
}

function B(e, r, n, u) {
    var I;
    var h = (n & A) !== 0,
        _ = (n & L) !== 0,
        x = (n & q) !== 0,
        o = e[r],
        t = (I = b(e, r)) == null ? void 0 : I.set,
        p = u,
        v = !0,
        m = () => (x && v && (v = !1, p = g(u)), p);
    o === void 0 && u !== void 0 && (t && _ && j(), o = m(), t && t(o));
    var i;
    if (_) i = () => {
        var s = e[r];
        return s === void 0 ? m() : (v = !0, s)
    };
    else {
        var w = (h ? O : C)(() => e[r]);
        w.f |= K, i = () => {
            var s = l(w);
            return s !== void 0 && (p = void 0), s === void 0 ? p : s
        }
    }
    if (!(n & R)) return i;
    if (t) {
        var D = e.$$legacy;
        return function(s, a) {
            return arguments.length > 0 ? ((!_ || !a || D) && t(a ? i() : s), s) : i()
        }
    }
    var d = !1,
        P = Y(o),
        f = O(() => {
            var s = i(),
                a = l(P);
            return d ? (d = !1, a) : P.v = s
        });
    return h || (f.equals = M),
        function(s, a) {
            var E = l(f);
            if (arguments.length > 0) {
                const S = a ? l(f) : s;
                return f.equals(S) || (d = !0, T(P, S), l(f)), s
            }
            return E
        }
}
export {
    V as l, B as p, Z as s
};