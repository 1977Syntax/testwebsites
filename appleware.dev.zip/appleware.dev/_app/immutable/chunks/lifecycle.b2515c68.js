import {
    a as r,
    b as e,
    Q as c,
    X as a,
    u as i,
    Y as u,
    g as l,
    O as _
} from "./runtime.712ce216.js";

function b() {
    const s = c,
        n = s.l.u;
    n && (n.b.length && r(() => {
        f(s), a(n.b)
    }), e(() => {
        const o = i(() => n.m.map(u));
        return () => {
            for (const t of o) typeof t == "function" && t()
        }
    }), n.a.length && e(() => {
        f(s), a(n.a)
    }))
}

function f(s) {
    if (s.l.s)
        for (const n of s.l.s) l(n);
    _(s.s)
}
export {
    b as i
};