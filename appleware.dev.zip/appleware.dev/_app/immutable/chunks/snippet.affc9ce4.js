import {
    l as f,
    E as n,
    v as o,
    L as p
} from "./runtime.712ce216.js";
import {
    h as c,
    i as h
} from "./disclose-version.91b4a1e6.js";

function m(e, i, ...s) {
    var t = e,
        r, a;
    f(() => {
        r !== (r = i()) && (a && (p(a), a = null), r && (a = o(() => r(t, ...s))))
    }, n), c && (t = h)
}
export {
    m as s
};