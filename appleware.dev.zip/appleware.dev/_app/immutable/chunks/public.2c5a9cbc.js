const e = globalThis.__sveltekit_f4svy0.env;
export {
    e
};