var xt = Object.defineProperty;
var bt = (s, t, n) => t in s ? xt(s, t, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: n
}) : s[t] = n;
var U = (s, t, n) => (bt(s, typeof t != "symbol" ? t + "" : t, n), n),
    wt = (s, t, n) => {
        if (!t.has(s)) throw TypeError("Cannot " + n)
    };
var Ne = (s, t, n) => {
    if (t.has(s)) throw TypeError("Cannot add the same private member more than once");
    t instanceof WeakSet ? t.add(s) : t.set(s, n)
};
var Re = (s, t, n) => (wt(s, t, "access private method"), n);
import {
    h as _t,
    i as Ye,
    g as vt,
    H as $t,
    m as Je,
    o as yt,
    p as zt,
    c as x,
    a as p,
    f as k,
    t as z,
    s as He,
    d as lt,
    r as S,
    b as I
} from "./disclose-version.91b4a1e6.js";
import {
    l as Tt,
    v as Rt,
    L as St,
    p as Le,
    c as qe,
    g as $,
    i as J,
    N as Ke,
    h as j,
    k as It,
    w as fe,
    s as ie,
    O as ge,
    x as at,
    m as oe,
    P as At
} from "./runtime.712ce216.js";
import {
    i as Be
} from "./lifecycle.b2515c68.js";
import {
    l as et,
    p as y,
    s as xe
} from "./props.a974af4b.js";
import {
    o as ot,
    c as Pt
} from "./index-client.e77d6254.js";
import {
    b as Ct,
    s as De
} from "./render.95e1ab5e.js";
import {
    i as N
} from "./if.c692dc35.js";
import {
    e as be,
    i as we
} from "./each.14627b3c.js";
import {
    c as G
} from "./svelte-component.351a274c.js";
import {
    s as P,
    d as C
} from "./misc.9c34d7d8.js";
import {
    s as H
} from "./attributes.0fe580a6.js";
import {
    s as Et
} from "./class.cca9bd46.js";

function Lt(s, t, n, e) {
    var r = s,
        i = "",
        l;
    Tt(() => {
        i !== (i = t()) && (l && (St(l), l = null), i !== "" && (l = Rt(() => {
            if (_t) {
                Ye.data;
                for (var a = vt(), o = a; a !== null && (a.nodeType !== 8 || a.data !== "");) o = a, a = a.nextSibling;
                if (a === null) throw Ct(), $t;
                Je(Ye, o), r = yt(a);
                return
            }
            var c = i + "";
            n ? c = `<svg>${c}</svg>` : e && (c = `<math>${c}</math>`);
            var d = zt(c);
            if ((n || e) && (d = d.firstChild), Je(d.firstChild, d.lastChild), n || e)
                for (; d.firstChild;) r.before(d.firstChild);
            else r.before(d)
        })))
    })
}

function qt() {
    const s = console.warn;
    console.warn = t => {
        t.includes("unknown prop") || t.includes("unexpected slot") || s(t)
    }, ot(() => {
        console.warn = s
    })
}
var Bt = z("<!> <!>", 1);

function me(s, t) {
    const n = et(t, ["children", "$$slots", "$$events", "$$legacy"]),
        e = et(n, ["type", "tokens", "header", "rows", "ordered", "renderers"]);
    Le(t, !1);
    let r = y(t, "type", 0, void 0),
        i = y(t, "tokens", 0, void 0),
        l = y(t, "header", 0, void 0),
        a = y(t, "rows", 0, void 0),
        o = y(t, "ordered", 0, !1),
        c = y(t, "renderers");
    qt(), Be();
    var d = x(),
        m = k(d);
    N(m, () => !r(), f => {
        var u = x(),
            T = k(u);
        be(T, 1, i, we, (A, q, w) => {
            var b = x(),
                L = k(b);
            me(L, xe(() => J(q), {
                get renderers() {
                    return c()
                },
                $$legacy: !0
            })), p(A, b)
        }), p(f, u)
    }, f => {
        var u = x(),
            T = k(u);
        N(T, () => c()[r()], A => {
            var q = x(),
                w = k(q);
            N(w, () => r() === "table", b => {
                var L = x(),
                    B = k(L);
                G(B, () => c().table, (R, E) => {
                    E(R, {
                        children: (Z, D) => {
                            var M = Bt(),
                                W = k(M);
                            G(W, () => c().tablehead, (X, ee) => {
                                ee(X, {
                                    children: (te, F) => {
                                        var V = x(),
                                            ue = k(V);
                                        G(ue, () => c().tablerow, (ne, _e) => {
                                            _e(ne, {
                                                children: (se, he) => {
                                                    var le = x(),
                                                        pe = k(le);
                                                    be(pe, 1, l, we, (de, ve, ae) => {
                                                        var re = x(),
                                                            Ze = k(re),
                                                            Ue = Ke(() => e.align[J(ae)] || "center");
                                                        G(Ze, () => c().tablecell, (je, Me) => {
                                                            Me(je, {
                                                                header: !0,
                                                                get align() {
                                                                    return $(Ue)
                                                                },
                                                                children: (ze, Ge) => {
                                                                    var Te = x(),
                                                                        Qe = k(Te);
                                                                    me(Qe, {
                                                                        get tokens() {
                                                                            return J(ve).tokens
                                                                        },
                                                                        get renderers() {
                                                                            return c()
                                                                        },
                                                                        $$legacy: !0
                                                                    }), p(ze, Te)
                                                                },
                                                                $$slots: {
                                                                    default: !0
                                                                },
                                                                $$legacy: !0
                                                            })
                                                        }), p(de, re)
                                                    }), p(se, le)
                                                },
                                                $$slots: {
                                                    default: !0
                                                },
                                                $$legacy: !0
                                            })
                                        }), p(te, V)
                                    },
                                    $$slots: {
                                        default: !0
                                    },
                                    $$legacy: !0
                                })
                            });
                            var Q = He(He(W, !0));
                            G(Q, () => c().tablebody, (X, ee) => {
                                ee(X, {
                                    children: (te, F) => {
                                        var V = x(),
                                            ue = k(V);
                                        be(ue, 1, a, we, (ne, _e, se) => {
                                            var he = x(),
                                                le = k(he);
                                            G(le, () => c().tablerow, (pe, de) => {
                                                de(pe, {
                                                    children: (ve, ae) => {
                                                        var re = x(),
                                                            Ze = k(re);
                                                        be(Ze, 1, () => J(_e), we, (Ue, je, Me) => {
                                                            var ze = x(),
                                                                Ge = k(ze),
                                                                Te = Ke(() => e.align[J(Me)] || "center");
                                                            G(Ge, () => c().tablecell, (Qe, gt) => {
                                                                gt(Qe, {
                                                                    header: !1,
                                                                    get align() {
                                                                        return $(Te)
                                                                    },
                                                                    children: (mt, Gn) => {
                                                                        var Ve = x(),
                                                                            kt = k(Ve);
                                                                        me(kt, {
                                                                            get tokens() {
                                                                                return J(je).tokens
                                                                            },
                                                                            get renderers() {
                                                                                return c()
                                                                            },
                                                                            $$legacy: !0
                                                                        }), p(mt, Ve)
                                                                    },
                                                                    $$slots: {
                                                                        default: !0
                                                                    },
                                                                    $$legacy: !0
                                                                })
                                                            }), p(Ue, ze)
                                                        }), p(ve, re)
                                                    },
                                                    $$slots: {
                                                        default: !0
                                                    },
                                                    $$legacy: !0
                                                })
                                            }), p(ne, he)
                                        }), p(te, V)
                                    },
                                    $$slots: {
                                        default: !0
                                    },
                                    $$legacy: !0
                                })
                            }), p(Z, M)
                        },
                        $$slots: {
                            default: !0
                        },
                        $$legacy: !0
                    })
                }), p(b, L)
            }, b => {
                var L = x(),
                    B = k(L);
                N(B, () => r() === "list", R => {
                    var E = x(),
                        Z = k(E);
                    N(Z, o, D => {
                        var M = x(),
                            W = k(M);
                        G(W, () => c().list, (Q, X) => {
                            X(Q, xe({
                                get ordered() {
                                    return o()
                                }
                            }, () => e, {
                                children: (ee, te) => {
                                    var F = x(),
                                        V = k(F);
                                    be(V, 1, () => e.items, we, (ue, ne, _e) => {
                                        var se = x(),
                                            he = k(se);
                                        G(he, () => c().orderedlistitem || c().listitem, (le, pe) => {
                                            pe(le, xe(() => J(ne), {
                                                children: (de, ve) => {
                                                    var ae = x(),
                                                        re = k(ae);
                                                    me(re, {
                                                        get tokens() {
                                                            return J(ne).tokens
                                                        },
                                                        get renderers() {
                                                            return c()
                                                        },
                                                        $$legacy: !0
                                                    }), p(de, ae)
                                                },
                                                $$slots: {
                                                    default: !0
                                                },
                                                $$legacy: !0
                                            }))
                                        }), p(ue, se)
                                    }), p(ee, F)
                                },
                                $$slots: {
                                    default: !0
                                },
                                $$legacy: !0
                            }))
                        }), p(D, M)
                    }, D => {
                        var M = x(),
                            W = k(M);
                        G(W, () => c().list, (Q, X) => {
                            X(Q, xe({
                                get ordered() {
                                    return o()
                                }
                            }, () => e, {
                                children: (ee, te) => {
                                    var F = x(),
                                        V = k(F);
                                    be(V, 1, () => e.items, we, (ue, ne, _e) => {
                                        var se = x(),
                                            he = k(se);
                                        G(he, () => c().unorderedlistitem || c().listitem, (le, pe) => {
                                            pe(le, xe(() => J(ne), {
                                                children: (de, ve) => {
                                                    var ae = x(),
                                                        re = k(ae);
                                                    me(re, {
                                                        get tokens() {
                                                            return J(ne).tokens
                                                        },
                                                        get renderers() {
                                                            return c()
                                                        },
                                                        $$legacy: !0
                                                    }), p(de, ae)
                                                },
                                                $$slots: {
                                                    default: !0
                                                },
                                                $$legacy: !0
                                            }))
                                        }), p(ue, se)
                                    }), p(ee, F)
                                },
                                $$slots: {
                                    default: !0
                                },
                                $$legacy: !0
                            }))
                        }), p(D, M)
                    }), p(R, E)
                }, R => {
                    var E = x(),
                        Z = k(E);
                    G(Z, () => c()[r()], (D, M) => {
                        M(D, xe(() => e, {
                            children: (W, Q) => {
                                var X = x(),
                                    ee = k(X);
                                N(ee, i, te => {
                                    var F = x(),
                                        V = k(F);
                                    me(V, {
                                        get tokens() {
                                            return i()
                                        },
                                        get renderers() {
                                            return c()
                                        },
                                        $$legacy: !0
                                    }), p(te, F)
                                }, te => {
                                    var F = lt();
                                    j(() => De(F, e.raw)), p(te, F)
                                }), p(W, X)
                            },
                            $$slots: {
                                default: !0
                            },
                            $$legacy: !0
                        }))
                    }), p(R, E)
                }, !0), p(b, L)
            }), p(A, q)
        }), p(f, u)
    }), p(s, d), qe()
}

function We() {
    return {
        async: !1,
        baseUrl: null,
        breaks: !1,
        extensions: null,
        gfm: !0,
        headerIds: !0,
        headerPrefix: "",
        highlight: null,
        hooks: null,
        langPrefix: "language-",
        mangle: !0,
        pedantic: !1,
        renderer: null,
        sanitize: !1,
        sanitizer: null,
        silent: !1,
        smartypants: !1,
        tokenizer: null,
        walkTokens: null,
        xhtml: !1
    }
}
let ce = We();

function ct(s) {
    ce = s
}
const ut = /[&<>"']/,
    Dt = new RegExp(ut.source, "g"),
    ht = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
    Ot = new RegExp(ht.source, "g"),
    Zt = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    },
    tt = s => Zt[s];

function O(s, t) {
    if (t) {
        if (ut.test(s)) return s.replace(Dt, tt)
    } else if (ht.test(s)) return s.replace(Ot, tt);
    return s
}
const Ut = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;

function pt(s) {
    return s.replace(Ut, (t, n) => (n = n.toLowerCase(), n === "colon" ? ":" : n.charAt(0) === "#" ? n.charAt(1) === "x" ? String.fromCharCode(parseInt(n.substring(2), 16)) : String.fromCharCode(+n.substring(1)) : ""))
}
const jt = /(^|[^\[])\^/g;

function _(s, t) {
    s = typeof s == "string" ? s : s.source, t = t || "";
    const n = {
        replace: (e, r) => (r = r.source || r, r = r.replace(jt, "$1"), s = s.replace(e, r), n),
        getRegex: () => new RegExp(s, t)
    };
    return n
}
const Mt = /[^\w:]/g,
    Qt = /^$|^[a-z][a-z0-9+.-]*:|^[?#]/i;

function nt(s, t, n) {
    if (s) {
        let e;
        try {
            e = decodeURIComponent(pt(n)).replace(Mt, "").toLowerCase()
        } catch {
            return null
        }
        if (e.indexOf("javascript:") === 0 || e.indexOf("vbscript:") === 0 || e.indexOf("data:") === 0) return null
    }
    t && !Qt.test(n) && (n = Wt(t, n));
    try {
        n = encodeURI(n).replace(/%25/g, "%")
    } catch {
        return null
    }
    return n
}
const Se = {},
    Nt = /^[^:]+:\/*[^/]*$/,
    Ht = /^([^:]+:)[\s\S]*$/,
    Ft = /^([^:]+:\/*[^/]*)[\s\S]*$/;

function Wt(s, t) {
    Se[" " + s] || (Nt.test(s) ? Se[" " + s] = s + "/" : Se[" " + s] = Ie(s, "/", !0)), s = Se[" " + s];
    const n = s.indexOf(":") === -1;
    return t.substring(0, 2) === "//" ? n ? t : s.replace(Ht, "$1") + t : t.charAt(0) === "/" ? n ? t : s.replace(Ft, "$1") + t : s + t
}
const Ae = {
    exec: function() {}
};

function rt(s, t) {
    const n = s.replace(/\|/g, (i, l, a) => {
            let o = !1,
                c = l;
            for (; --c >= 0 && a[c] === "\\";) o = !o;
            return o ? "|" : " |"
        }),
        e = n.split(/ \|/);
    let r = 0;
    if (e[0].trim() || e.shift(), e.length > 0 && !e[e.length - 1].trim() && e.pop(), e.length > t) e.splice(t);
    else
        for (; e.length < t;) e.push("");
    for (; r < e.length; r++) e[r] = e[r].trim().replace(/\\\|/g, "|");
    return e
}

function Ie(s, t, n) {
    const e = s.length;
    if (e === 0) return "";
    let r = 0;
    for (; r < e;) {
        const i = s.charAt(e - r - 1);
        if (i === t && !n) r++;
        else if (i !== t && n) r++;
        else break
    }
    return s.slice(0, e - r)
}

function Xt(s, t) {
    if (s.indexOf(t[1]) === -1) return -1;
    const n = s.length;
    let e = 0,
        r = 0;
    for (; r < n; r++)
        if (s[r] === "\\") r++;
        else if (s[r] === t[0]) e++;
    else if (s[r] === t[1] && (e--, e < 0)) return r;
    return -1
}

function Gt(s, t) {
    !s || s.silent || (t && console.warn("marked(): callback is deprecated since version 5.0.0, should not be used and will be removed in the future. Read more here: https://marked.js.org/using_pro#async"), (s.sanitize || s.sanitizer) && console.warn("marked(): sanitize and sanitizer parameters are deprecated since version 0.7.0, should not be used and will be removed in the future. Read more here: https://marked.js.org/#/USING_ADVANCED.md#options"), (s.highlight || s.langPrefix !== "language-") && console.warn("marked(): highlight and langPrefix parameters are deprecated since version 5.0.0, should not be used and will be removed in the future. Instead use https://www.npmjs.com/package/marked-highlight."), s.mangle && console.warn("marked(): mangle parameter is enabled by default, but is deprecated since version 5.0.0, and will be removed in the future. To clear this warning, install https://www.npmjs.com/package/marked-mangle, or disable by setting `{mangle: false}`."), s.baseUrl && console.warn("marked(): baseUrl parameter is deprecated since version 5.0.0, should not be used and will be removed in the future. Instead use https://www.npmjs.com/package/marked-base-url."), s.smartypants && console.warn("marked(): smartypants parameter is deprecated since version 5.0.0, should not be used and will be removed in the future. Instead use https://www.npmjs.com/package/marked-smartypants."), s.xhtml && console.warn("marked(): xhtml parameter is deprecated since version 5.0.0, should not be used and will be removed in the future. Instead use https://www.npmjs.com/package/marked-xhtml."), (s.headerIds || s.headerPrefix) && console.warn("marked(): headerIds and headerPrefix parameters enabled by default, but are deprecated since version 5.0.0, and will be removed in the future. To clear this warning, install  https://www.npmjs.com/package/marked-gfm-heading-id, or disable by setting `{headerIds: false}`."))
}

function it(s, t, n, e) {
    const r = t.href,
        i = t.title ? O(t.title) : null,
        l = s[1].replace(/\\([\[\]])/g, "$1");
    if (s[0].charAt(0) !== "!") {
        e.state.inLink = !0;
        const a = {
            type: "link",
            raw: n,
            href: r,
            title: i,
            text: l,
            tokens: e.inlineTokens(l)
        };
        return e.state.inLink = !1, a
    }
    return {
        type: "image",
        raw: n,
        href: r,
        title: i,
        text: O(l)
    }
}

function Vt(s, t) {
    const n = s.match(/^(\s+)(?:```)/);
    if (n === null) return t;
    const e = n[1];
    return t.split(`
`).map(r => {
        const i = r.match(/^\s+/);
        if (i === null) return r;
        const [l] = i;
        return l.length >= e.length ? r.slice(e.length) : r
    }).join(`
`)
}
class Pe {
    constructor(t) {
        this.options = t || ce
    }
    space(t) {
        const n = this.rules.block.newline.exec(t);
        if (n && n[0].length > 0) return {
            type: "space",
            raw: n[0]
        }
    }
    code(t) {
        const n = this.rules.block.code.exec(t);
        if (n) {
            const e = n[0].replace(/^ {1,4}/gm, "");
            return {
                type: "code",
                raw: n[0],
                codeBlockStyle: "indented",
                text: this.options.pedantic ? e : Ie(e, `
`)
            }
        }
    }
    fences(t) {
        const n = this.rules.block.fences.exec(t);
        if (n) {
            const e = n[0],
                r = Vt(e, n[3] || "");
            return {
                type: "code",
                raw: e,
                lang: n[2] ? n[2].trim().replace(this.rules.inline._escapes, "$1") : n[2],
                text: r
            }
        }
    }
    heading(t) {
        const n = this.rules.block.heading.exec(t);
        if (n) {
            let e = n[2].trim();
            if (/#$/.test(e)) {
                const r = Ie(e, "#");
                (this.options.pedantic || !r || / $/.test(r)) && (e = r.trim())
            }
            return {
                type: "heading",
                raw: n[0],
                depth: n[1].length,
                text: e,
                tokens: this.lexer.inline(e)
            }
        }
    }
    hr(t) {
        const n = this.rules.block.hr.exec(t);
        if (n) return {
            type: "hr",
            raw: n[0]
        }
    }
    blockquote(t) {
        const n = this.rules.block.blockquote.exec(t);
        if (n) {
            const e = n[0].replace(/^ *>[ \t]?/gm, ""),
                r = this.lexer.state.top;
            this.lexer.state.top = !0;
            const i = this.lexer.blockTokens(e);
            return this.lexer.state.top = r, {
                type: "blockquote",
                raw: n[0],
                tokens: i,
                text: e
            }
        }
    }
    list(t) {
        let n = this.rules.block.list.exec(t);
        if (n) {
            let e, r, i, l, a, o, c, d, m, f, u, T, A = n[1].trim();
            const q = A.length > 1,
                w = {
                    type: "list",
                    raw: "",
                    ordered: q,
                    start: q ? +A.slice(0, -1) : "",
                    loose: !1,
                    items: []
                };
            A = q ? `\\d{1,9}\\${A.slice(-1)}` : `\\${A}`, this.options.pedantic && (A = q ? A : "[*+-]");
            const b = new RegExp(`^( {0,3}${A})((?:[	 ][^\\n]*)?(?:\\n|$))`);
            for (; t && (T = !1, !(!(n = b.exec(t)) || this.rules.block.hr.test(t)));) {
                if (e = n[0], t = t.substring(e.length), d = n[2].split(`
`, 1)[0].replace(/^\t+/, B => " ".repeat(3 * B.length)), m = t.split(`
`, 1)[0], this.options.pedantic ? (l = 2, u = d.trimLeft()) : (l = n[2].search(/[^ ]/), l = l > 4 ? 1 : l, u = d.slice(l), l += n[1].length), o = !1, !d && /^ *$/.test(m) && (e += m + `
`, t = t.substring(m.length + 1), T = !0), !T) {
                    const B = new RegExp(`^ {0,${Math.min(3,l-1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),
                        R = new RegExp(`^ {0,${Math.min(3,l-1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),
                        E = new RegExp(`^ {0,${Math.min(3,l-1)}}(?:\`\`\`|~~~)`),
                        Z = new RegExp(`^ {0,${Math.min(3,l-1)}}#`);
                    for (; t && (f = t.split(`
`, 1)[0], m = f, this.options.pedantic && (m = m.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), !(E.test(m) || Z.test(m) || B.test(m) || R.test(t)));) {
                        if (m.search(/[^ ]/) >= l || !m.trim()) u += `
` + m.slice(l);
                        else {
                            if (o || d.search(/[^ ]/) >= 4 || E.test(d) || Z.test(d) || R.test(d)) break;
                            u += `
` + m
                        }!o && !m.trim() && (o = !0), e += f + `
`, t = t.substring(f.length + 1), d = m.slice(l)
                    }
                }
                w.loose || (c ? w.loose = !0 : /\n *\n *$/.test(e) && (c = !0)), this.options.gfm && (r = /^\[[ xX]\] /.exec(u), r && (i = r[0] !== "[ ] ", u = u.replace(/^\[[ xX]\] +/, ""))), w.items.push({
                    type: "list_item",
                    raw: e,
                    task: !!r,
                    checked: i,
                    loose: !1,
                    text: u
                }), w.raw += e
            }
            w.items[w.items.length - 1].raw = e.trimRight(), w.items[w.items.length - 1].text = u.trimRight(), w.raw = w.raw.trimRight();
            const L = w.items.length;
            for (a = 0; a < L; a++)
                if (this.lexer.state.top = !1, w.items[a].tokens = this.lexer.blockTokens(w.items[a].text, []), !w.loose) {
                    const B = w.items[a].tokens.filter(E => E.type === "space"),
                        R = B.length > 0 && B.some(E => /\n.*\n/.test(E.raw));
                    w.loose = R
                }
            if (w.loose)
                for (a = 0; a < L; a++) w.items[a].loose = !0;
            return w
        }
    }
    html(t) {
        const n = this.rules.block.html.exec(t);
        if (n) {
            const e = {
                type: "html",
                block: !0,
                raw: n[0],
                pre: !this.options.sanitizer && (n[1] === "pre" || n[1] === "script" || n[1] === "style"),
                text: n[0]
            };
            if (this.options.sanitize) {
                const r = this.options.sanitizer ? this.options.sanitizer(n[0]) : O(n[0]);
                e.type = "paragraph", e.text = r, e.tokens = this.lexer.inline(r)
            }
            return e
        }
    }
    def(t) {
        const n = this.rules.block.def.exec(t);
        if (n) {
            const e = n[1].toLowerCase().replace(/\s+/g, " "),
                r = n[2] ? n[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline._escapes, "$1") : "",
                i = n[3] ? n[3].substring(1, n[3].length - 1).replace(this.rules.inline._escapes, "$1") : n[3];
            return {
                type: "def",
                tag: e,
                raw: n[0],
                href: r,
                title: i
            }
        }
    }
    table(t) {
        const n = this.rules.block.table.exec(t);
        if (n) {
            const e = {
                type: "table",
                header: rt(n[1]).map(r => ({
                    text: r
                })),
                align: n[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
                rows: n[3] && n[3].trim() ? n[3].replace(/\n[ \t]*$/, "").split(`
`) : []
            };
            if (e.header.length === e.align.length) {
                e.raw = n[0];
                let r = e.align.length,
                    i, l, a, o;
                for (i = 0; i < r; i++) /^ *-+: *$/.test(e.align[i]) ? e.align[i] = "right" : /^ *:-+: *$/.test(e.align[i]) ? e.align[i] = "center" : /^ *:-+ *$/.test(e.align[i]) ? e.align[i] = "left" : e.align[i] = null;
                for (r = e.rows.length, i = 0; i < r; i++) e.rows[i] = rt(e.rows[i], e.header.length).map(c => ({
                    text: c
                }));
                for (r = e.header.length, l = 0; l < r; l++) e.header[l].tokens = this.lexer.inline(e.header[l].text);
                for (r = e.rows.length, l = 0; l < r; l++)
                    for (o = e.rows[l], a = 0; a < o.length; a++) o[a].tokens = this.lexer.inline(o[a].text);
                return e
            }
        }
    }
    lheading(t) {
        const n = this.rules.block.lheading.exec(t);
        if (n) return {
            type: "heading",
            raw: n[0],
            depth: n[2].charAt(0) === "=" ? 1 : 2,
            text: n[1],
            tokens: this.lexer.inline(n[1])
        }
    }
    paragraph(t) {
        const n = this.rules.block.paragraph.exec(t);
        if (n) {
            const e = n[1].charAt(n[1].length - 1) === `
` ? n[1].slice(0, -1) : n[1];
            return {
                type: "paragraph",
                raw: n[0],
                text: e,
                tokens: this.lexer.inline(e)
            }
        }
    }
    text(t) {
        const n = this.rules.block.text.exec(t);
        if (n) return {
            type: "text",
            raw: n[0],
            text: n[0],
            tokens: this.lexer.inline(n[0])
        }
    }
    escape(t) {
        const n = this.rules.inline.escape.exec(t);
        if (n) return {
            type: "escape",
            raw: n[0],
            text: O(n[1])
        }
    }
    tag(t) {
        const n = this.rules.inline.tag.exec(t);
        if (n) return !this.lexer.state.inLink && /^<a /i.test(n[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(n[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(n[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(n[0]) && (this.lexer.state.inRawBlock = !1), {
            type: this.options.sanitize ? "text" : "html",
            raw: n[0],
            inLink: this.lexer.state.inLink,
            inRawBlock: this.lexer.state.inRawBlock,
            block: !1,
            text: this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(n[0]) : O(n[0]) : n[0]
        }
    }
    link(t) {
        const n = this.rules.inline.link.exec(t);
        if (n) {
            const e = n[2].trim();
            if (!this.options.pedantic && /^</.test(e)) {
                if (!/>$/.test(e)) return;
                const l = Ie(e.slice(0, -1), "\\");
                if ((e.length - l.length) % 2 === 0) return
            } else {
                const l = Xt(n[2], "()");
                if (l > -1) {
                    const o = (n[0].indexOf("!") === 0 ? 5 : 4) + n[1].length + l;
                    n[2] = n[2].substring(0, l), n[0] = n[0].substring(0, o).trim(), n[3] = ""
                }
            }
            let r = n[2],
                i = "";
            if (this.options.pedantic) {
                const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(r);
                l && (r = l[1], i = l[3])
            } else i = n[3] ? n[3].slice(1, -1) : "";
            return r = r.trim(), /^</.test(r) && (this.options.pedantic && !/>$/.test(e) ? r = r.slice(1) : r = r.slice(1, -1)), it(n, {
                href: r && r.replace(this.rules.inline._escapes, "$1"),
                title: i && i.replace(this.rules.inline._escapes, "$1")
            }, n[0], this.lexer)
        }
    }
    reflink(t, n) {
        let e;
        if ((e = this.rules.inline.reflink.exec(t)) || (e = this.rules.inline.nolink.exec(t))) {
            let r = (e[2] || e[1]).replace(/\s+/g, " ");
            if (r = n[r.toLowerCase()], !r) {
                const i = e[0].charAt(0);
                return {
                    type: "text",
                    raw: i,
                    text: i
                }
            }
            return it(e, r, e[0], this.lexer)
        }
    }
    emStrong(t, n, e = "") {
        let r = this.rules.inline.emStrong.lDelim.exec(t);
        if (!r || r[3] && e.match(/[\p{L}\p{N}]/u)) return;
        if (!(r[1] || r[2] || "") || !e || this.rules.inline.punctuation.exec(e)) {
            const l = r[0].length - 1;
            let a, o, c = l,
                d = 0;
            const m = r[0][0] === "*" ? this.rules.inline.emStrong.rDelimAst : this.rules.inline.emStrong.rDelimUnd;
            for (m.lastIndex = 0, n = n.slice(-1 * t.length + l);
                (r = m.exec(n)) != null;) {
                if (a = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !a) continue;
                if (o = a.length, r[3] || r[4]) {
                    c += o;
                    continue
                } else if ((r[5] || r[6]) && l % 3 && !((l + o) % 3)) {
                    d += o;
                    continue
                }
                if (c -= o, c > 0) continue;
                o = Math.min(o, o + c + d);
                const f = t.slice(0, l + r.index + o + 1);
                if (Math.min(l, o) % 2) {
                    const T = f.slice(1, -1);
                    return {
                        type: "em",
                        raw: f,
                        text: T,
                        tokens: this.lexer.inlineTokens(T)
                    }
                }
                const u = f.slice(2, -2);
                return {
                    type: "strong",
                    raw: f,
                    text: u,
                    tokens: this.lexer.inlineTokens(u)
                }
            }
        }
    }
    codespan(t) {
        const n = this.rules.inline.code.exec(t);
        if (n) {
            let e = n[2].replace(/\n/g, " ");
            const r = /[^ ]/.test(e),
                i = /^ /.test(e) && / $/.test(e);
            return r && i && (e = e.substring(1, e.length - 1)), e = O(e, !0), {
                type: "codespan",
                raw: n[0],
                text: e
            }
        }
    }
    br(t) {
        const n = this.rules.inline.br.exec(t);
        if (n) return {
            type: "br",
            raw: n[0]
        }
    }
    del(t) {
        const n = this.rules.inline.del.exec(t);
        if (n) return {
            type: "del",
            raw: n[0],
            text: n[2],
            tokens: this.lexer.inlineTokens(n[2])
        }
    }
    autolink(t, n) {
        const e = this.rules.inline.autolink.exec(t);
        if (e) {
            let r, i;
            return e[2] === "@" ? (r = O(this.options.mangle ? n(e[1]) : e[1]), i = "mailto:" + r) : (r = O(e[1]), i = r), {
                type: "link",
                raw: e[0],
                text: r,
                href: i,
                tokens: [{
                    type: "text",
                    raw: r,
                    text: r
                }]
            }
        }
    }
    url(t, n) {
        let e;
        if (e = this.rules.inline.url.exec(t)) {
            let r, i;
            if (e[2] === "@") r = O(this.options.mangle ? n(e[0]) : e[0]), i = "mailto:" + r;
            else {
                let l;
                do l = e[0], e[0] = this.rules.inline._backpedal.exec(e[0])[0]; while (l !== e[0]);
                r = O(e[0]), e[1] === "www." ? i = "http://" + e[0] : i = e[0]
            }
            return {
                type: "link",
                raw: e[0],
                text: r,
                href: i,
                tokens: [{
                    type: "text",
                    raw: r,
                    text: r
                }]
            }
        }
    }
    inlineText(t, n) {
        const e = this.rules.inline.text.exec(t);
        if (e) {
            let r;
            return this.lexer.state.inRawBlock ? r = this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(e[0]) : O(e[0]) : e[0] : r = O(this.options.smartypants ? n(e[0]) : e[0]), {
                type: "text",
                raw: e[0],
                text: r
            }
        }
    }
}
const g = {
    newline: /^(?: *(?:\n|$))+/,
    code: /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/,
    fences: /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,
    hr: /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,
    heading: /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,
    blockquote: /^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/,
    list: /^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/,
    html: "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))",
    def: /^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/,
    table: Ae,
    lheading: /^((?:(?!^bull ).|\n(?!\n|bull ))+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
    _paragraph: /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/,
    text: /^[^\n]+/
};
g._label = /(?!\s*\])(?:\\.|[^\[\]\\])+/;
g._title = /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/;
g.def = _(g.def).replace("label", g._label).replace("title", g._title).getRegex();
g.bullet = /(?:[*+-]|\d{1,9}[.)])/;
g.listItemStart = _(/^( *)(bull) */).replace("bull", g.bullet).getRegex();
g.list = _(g.list).replace(/bull/g, g.bullet).replace("hr", "\\n+(?=\\1?(?:(?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$))").replace("def", "\\n+(?=" + g.def.source + ")").getRegex();
g._tag = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul";
g._comment = /<!--(?!-?>)[\s\S]*?(?:-->|$)/;
g.html = _(g.html, "i").replace("comment", g._comment).replace("tag", g._tag).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex();
g.lheading = _(g.lheading).replace(/bull/g, g.bullet).getRegex();
g.paragraph = _(g._paragraph).replace("hr", g.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", g._tag).getRegex();
g.blockquote = _(g.blockquote).replace("paragraph", g.paragraph).getRegex();
g.normal = { ...g
};
g.gfm = { ...g.normal,
    table: "^ *([^\\n ].*\\|.*)\\n {0,3}(?:\\| *)?(:?-+:? *(?:\\| *:?-+:? *)*)(?:\\| *)?(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
};
g.gfm.table = _(g.gfm.table).replace("hr", g.hr).replace("heading", " {0,3}#{1,6} ").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", g._tag).getRegex();
g.gfm.paragraph = _(g._paragraph).replace("hr", g.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("table", g.gfm.table).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", g._tag).getRegex();
g.pedantic = { ...g.normal,
    html: _(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", g._comment).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
    def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
    heading: /^(#{1,6})(.*)(?:\n+|$)/,
    fences: Ae,
    lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
    paragraph: _(g.normal._paragraph).replace("hr", g.hr).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", g.lheading).replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").getRegex()
};
const h = {
    escape: /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,
    autolink: /^<(scheme:[^\s\x00-\x1f<>]*|email)>/,
    url: Ae,
    tag: "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>",
    link: /^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/,
    reflink: /^!?\[(label)\]\[(ref)\]/,
    nolink: /^!?\[(ref)\](?:\[\])?/,
    reflinkSearch: "reflink|nolink(?!\\()",
    emStrong: {
        lDelim: /^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/,
        rDelimAst: /^[^_*]*?__[^_*]*?\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\*)[punct](\*+)(?=[\s]|$)|[^punct\s](\*+)(?!\*)(?=[punct\s]|$)|(?!\*)[punct\s](\*+)(?=[^punct\s])|[\s](\*+)(?!\*)(?=[punct])|(?!\*)[punct](\*+)(?!\*)(?=[punct])|[^punct\s](\*+)(?=[^punct\s])/,
        rDelimUnd: /^[^_*]*?\*\*[^_*]*?_[^_*]*?(?=\*\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\s]|$)|[^punct\s](_+)(?!_)(?=[punct\s]|$)|(?!_)[punct\s](_+)(?=[^punct\s])|[\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])/
    },
    code: /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,
    br: /^( {2,}|\\)\n(?!\s*$)/,
    del: Ae,
    text: /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,
    punctuation: /^((?![*_])[\spunctuation])/
};
h._punctuation = "\\p{P}$+<=>`^|~";
h.punctuation = _(h.punctuation, "u").replace(/punctuation/g, h._punctuation).getRegex();
h.blockSkip = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g;
h.anyPunctuation = /\\[punct]/g;
h._escapes = /\\([punct])/g;
h._comment = _(g._comment).replace("(?:-->|$)", "-->").getRegex();
h.emStrong.lDelim = _(h.emStrong.lDelim, "u").replace(/punct/g, h._punctuation).getRegex();
h.emStrong.rDelimAst = _(h.emStrong.rDelimAst, "gu").replace(/punct/g, h._punctuation).getRegex();
h.emStrong.rDelimUnd = _(h.emStrong.rDelimUnd, "gu").replace(/punct/g, h._punctuation).getRegex();
h.anyPunctuation = _(h.anyPunctuation, "gu").replace(/punct/g, h._punctuation).getRegex();
h._escapes = _(h._escapes, "gu").replace(/punct/g, h._punctuation).getRegex();
h._scheme = /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/;
h._email = /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/;
h.autolink = _(h.autolink).replace("scheme", h._scheme).replace("email", h._email).getRegex();
h._attribute = /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/;
h.tag = _(h.tag).replace("comment", h._comment).replace("attribute", h._attribute).getRegex();
h._label = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/;
h._href = /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/;
h._title = /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/;
h.link = _(h.link).replace("label", h._label).replace("href", h._href).replace("title", h._title).getRegex();
h.reflink = _(h.reflink).replace("label", h._label).replace("ref", g._label).getRegex();
h.nolink = _(h.nolink).replace("ref", g._label).getRegex();
h.reflinkSearch = _(h.reflinkSearch, "g").replace("reflink", h.reflink).replace("nolink", h.nolink).getRegex();
h.normal = { ...h
};
h.pedantic = { ...h.normal,
    strong: {
        start: /^__|\*\*/,
        middle: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,
        endAst: /\*\*(?!\*)/g,
        endUnd: /__(?!_)/g
    },
    em: {
        start: /^_|\*/,
        middle: /^()\*(?=\S)([\s\S]*?\S)\*(?!\*)|^_(?=\S)([\s\S]*?\S)_(?!_)/,
        endAst: /\*(?!\*)/g,
        endUnd: /_(?!_)/g
    },
    link: _(/^!?\[(label)\]\((.*?)\)/).replace("label", h._label).getRegex(),
    reflink: _(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", h._label).getRegex()
};
h.gfm = { ...h.normal,
    escape: _(h.escape).replace("])", "~|])").getRegex(),
    _extended_email: /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/,
    url: /^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,
    _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
    del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
    text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
};
h.gfm.url = _(h.gfm.url, "i").replace("email", h.gfm._extended_email).getRegex();
h.breaks = { ...h.gfm,
    br: _(h.br).replace("{2,}", "*").getRegex(),
    text: _(h.gfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
};

function Yt(s) {
    return s.replace(/---/g, "—").replace(/--/g, "–").replace(/(^|[-\u2014/(\[{"\s])'/g, "$1‘").replace(/'/g, "’").replace(/(^|[-\u2014/(\[{\u2018\s])"/g, "$1“").replace(/"/g, "”").replace(/\.{3}/g, "…")
}

function st(s) {
    let t = "",
        n, e;
    const r = s.length;
    for (n = 0; n < r; n++) e = s.charCodeAt(n), Math.random() > .5 && (e = "x" + e.toString(16)), t += "&#" + e + ";";
    return t
}
class Y {
    constructor(t) {
        this.tokens = [], this.tokens.links = Object.create(null), this.options = t || ce, this.options.tokenizer = this.options.tokenizer || new Pe, this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
            inLink: !1,
            inRawBlock: !1,
            top: !0
        };
        const n = {
            block: g.normal,
            inline: h.normal
        };
        this.options.pedantic ? (n.block = g.pedantic, n.inline = h.pedantic) : this.options.gfm && (n.block = g.gfm, this.options.breaks ? n.inline = h.breaks : n.inline = h.gfm), this.tokenizer.rules = n
    }
    static get rules() {
        return {
            block: g,
            inline: h
        }
    }
    static lex(t, n) {
        return new Y(n).lex(t)
    }
    static lexInline(t, n) {
        return new Y(n).inlineTokens(t)
    }
    lex(t) {
        t = t.replace(/\r\n|\r/g, `
`), this.blockTokens(t, this.tokens);
        let n;
        for (; n = this.inlineQueue.shift();) this.inlineTokens(n.src, n.tokens);
        return this.tokens
    }
    blockTokens(t, n = []) {
        this.options.pedantic ? t = t.replace(/\t/g, "    ").replace(/^ +$/gm, "") : t = t.replace(/^( *)(\t+)/gm, (a, o, c) => o + "    ".repeat(c.length));
        let e, r, i, l;
        for (; t;)
            if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some(a => (e = a.call({
                    lexer: this
                }, t, n)) ? (t = t.substring(e.raw.length), n.push(e), !0) : !1))) {
                if (e = this.tokenizer.space(t)) {
                    t = t.substring(e.raw.length), e.raw.length === 1 && n.length > 0 ? n[n.length - 1].raw += `
` : n.push(e);
                    continue
                }
                if (e = this.tokenizer.code(t)) {
                    t = t.substring(e.raw.length), r = n[n.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + e.raw, r.text += `
` + e.text, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(e);
                    continue
                }
                if (e = this.tokenizer.fences(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.heading(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.hr(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.blockquote(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.list(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.html(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.def(t)) {
                    t = t.substring(e.raw.length), r = n[n.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + e.raw, r.text += `
` + e.raw, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : this.tokens.links[e.tag] || (this.tokens.links[e.tag] = {
                        href: e.href,
                        title: e.title
                    });
                    continue
                }
                if (e = this.tokenizer.table(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.lheading(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (i = t, this.options.extensions && this.options.extensions.startBlock) {
                    let a = 1 / 0;
                    const o = t.slice(1);
                    let c;
                    this.options.extensions.startBlock.forEach(function(d) {
                        c = d.call({
                            lexer: this
                        }, o), typeof c == "number" && c >= 0 && (a = Math.min(a, c))
                    }), a < 1 / 0 && a >= 0 && (i = t.substring(0, a + 1))
                }
                if (this.state.top && (e = this.tokenizer.paragraph(i))) {
                    r = n[n.length - 1], l && r.type === "paragraph" ? (r.raw += `
` + e.raw, r.text += `
` + e.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(e), l = i.length !== t.length, t = t.substring(e.raw.length);
                    continue
                }
                if (e = this.tokenizer.text(t)) {
                    t = t.substring(e.raw.length), r = n[n.length - 1], r && r.type === "text" ? (r.raw += `
` + e.raw, r.text += `
` + e.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(e);
                    continue
                }
                if (t) {
                    const a = "Infinite loop on byte: " + t.charCodeAt(0);
                    if (this.options.silent) {
                        console.error(a);
                        break
                    } else throw new Error(a)
                }
            }
        return this.state.top = !0, n
    }
    inline(t, n = []) {
        return this.inlineQueue.push({
            src: t,
            tokens: n
        }), n
    }
    inlineTokens(t, n = []) {
        let e, r, i, l = t,
            a, o, c;
        if (this.tokens.links) {
            const d = Object.keys(this.tokens.links);
            if (d.length > 0)
                for (;
                    (a = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null;) d.includes(a[0].slice(a[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, a.index) + "[" + "a".repeat(a[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex))
        }
        for (;
            (a = this.tokenizer.rules.inline.blockSkip.exec(l)) != null;) l = l.slice(0, a.index) + "[" + "a".repeat(a[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
        for (;
            (a = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null;) l = l.slice(0, a.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
        for (; t;)
            if (o || (c = ""), o = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some(d => (e = d.call({
                    lexer: this
                }, t, n)) ? (t = t.substring(e.raw.length), n.push(e), !0) : !1))) {
                if (e = this.tokenizer.escape(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.tag(t)) {
                    t = t.substring(e.raw.length), r = n[n.length - 1], r && e.type === "text" && r.type === "text" ? (r.raw += e.raw, r.text += e.text) : n.push(e);
                    continue
                }
                if (e = this.tokenizer.link(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.reflink(t, this.tokens.links)) {
                    t = t.substring(e.raw.length), r = n[n.length - 1], r && e.type === "text" && r.type === "text" ? (r.raw += e.raw, r.text += e.text) : n.push(e);
                    continue
                }
                if (e = this.tokenizer.emStrong(t, l, c)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.codespan(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.br(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.del(t)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (e = this.tokenizer.autolink(t, st)) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (!this.state.inLink && (e = this.tokenizer.url(t, st))) {
                    t = t.substring(e.raw.length), n.push(e);
                    continue
                }
                if (i = t, this.options.extensions && this.options.extensions.startInline) {
                    let d = 1 / 0;
                    const m = t.slice(1);
                    let f;
                    this.options.extensions.startInline.forEach(function(u) {
                        f = u.call({
                            lexer: this
                        }, m), typeof f == "number" && f >= 0 && (d = Math.min(d, f))
                    }), d < 1 / 0 && d >= 0 && (i = t.substring(0, d + 1))
                }
                if (e = this.tokenizer.inlineText(i, Yt)) {
                    t = t.substring(e.raw.length), e.raw.slice(-1) !== "_" && (c = e.raw.slice(-1)), o = !0, r = n[n.length - 1], r && r.type === "text" ? (r.raw += e.raw, r.text += e.text) : n.push(e);
                    continue
                }
                if (t) {
                    const d = "Infinite loop on byte: " + t.charCodeAt(0);
                    if (this.options.silent) {
                        console.error(d);
                        break
                    } else throw new Error(d)
                }
            }
        return n
    }
}
class Ce {
    constructor(t) {
        this.options = t || ce
    }
    code(t, n, e) {
        const r = (n || "").match(/\S*/)[0];
        if (this.options.highlight) {
            const i = this.options.highlight(t, r);
            i != null && i !== t && (e = !0, t = i)
        }
        return t = t.replace(/\n$/, "") + `
`, r ? '<pre><code class="' + this.options.langPrefix + O(r) + '">' + (e ? t : O(t, !0)) + `</code></pre>
` : "<pre><code>" + (e ? t : O(t, !0)) + `</code></pre>
`
    }
    blockquote(t) {
        return `<blockquote>
${t}</blockquote>
`
    }
    html(t, n) {
        return t
    }
    heading(t, n, e, r) {
        if (this.options.headerIds) {
            const i = this.options.headerPrefix + r.slug(e);
            return `<h${n} id="${i}">${t}</h${n}>
`
        }
        return `<h${n}>${t}</h${n}>
`
    }
    hr() {
        return this.options.xhtml ? `<hr/>
` : `<hr>
`
    }
    list(t, n, e) {
        const r = n ? "ol" : "ul",
            i = n && e !== 1 ? ' start="' + e + '"' : "";
        return "<" + r + i + `>
` + t + "</" + r + `>
`
    }
    listitem(t) {
        return `<li>${t}</li>
`
    }
    checkbox(t) {
        return "<input " + (t ? 'checked="" ' : "") + 'disabled="" type="checkbox"' + (this.options.xhtml ? " /" : "") + "> "
    }
    paragraph(t) {
        return `<p>${t}</p>
`
    }
    table(t, n) {
        return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + n + `</table>
`
    }
    tablerow(t) {
        return `<tr>
${t}</tr>
`
    }
    tablecell(t, n) {
        const e = n.header ? "th" : "td";
        return (n.align ? `<${e} align="${n.align}">` : `<${e}>`) + t + `</${e}>
`
    }
    strong(t) {
        return `<strong>${t}</strong>`
    }
    em(t) {
        return `<em>${t}</em>`
    }
    codespan(t) {
        return `<code>${t}</code>`
    }
    br() {
        return this.options.xhtml ? "<br/>" : "<br>"
    }
    del(t) {
        return `<del>${t}</del>`
    }
    link(t, n, e) {
        if (t = nt(this.options.sanitize, this.options.baseUrl, t), t === null) return e;
        let r = '<a href="' + t + '"';
        return n && (r += ' title="' + n + '"'), r += ">" + e + "</a>", r
    }
    image(t, n, e) {
        if (t = nt(this.options.sanitize, this.options.baseUrl, t), t === null) return e;
        let r = `<img src="${t}" alt="${e}"`;
        return n && (r += ` title="${n}"`), r += this.options.xhtml ? "/>" : ">", r
    }
    text(t) {
        return t
    }
}
class Xe {
    strong(t) {
        return t
    }
    em(t) {
        return t
    }
    codespan(t) {
        return t
    }
    del(t) {
        return t
    }
    html(t) {
        return t
    }
    text(t) {
        return t
    }
    link(t, n, e) {
        return "" + e
    }
    image(t, n, e) {
        return "" + e
    }
    br() {
        return ""
    }
}
class Oe {
    constructor() {
        this.seen = {}
    }
    serialize(t) {
        return t.toLowerCase().trim().replace(/<[!\/a-z].*?>/ig, "").replace(/[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,./:;<=>?@[\]^`{|}~]/g, "").replace(/\s/g, "-")
    }
    getNextSafeSlug(t, n) {
        let e = t,
            r = 0;
        if (this.seen.hasOwnProperty(e)) {
            r = this.seen[t];
            do r++, e = t + "-" + r; while (this.seen.hasOwnProperty(e))
        }
        return n || (this.seen[t] = r, this.seen[e] = 0), e
    }
    slug(t, n = {}) {
        const e = this.serialize(t);
        return this.getNextSafeSlug(e, n.dryrun)
    }
}
class K {
    constructor(t) {
        this.options = t || ce, this.options.renderer = this.options.renderer || new Ce, this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Xe, this.slugger = new Oe
    }
    static parse(t, n) {
        return new K(n).parse(t)
    }
    static parseInline(t, n) {
        return new K(n).parseInline(t)
    }
    parse(t, n = !0) {
        let e = "",
            r, i, l, a, o, c, d, m, f, u, T, A, q, w, b, L, B, R, E;
        const Z = t.length;
        for (r = 0; r < Z; r++) {
            if (u = t[r], this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[u.type] && (E = this.options.extensions.renderers[u.type].call({
                    parser: this
                }, u), E !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(u.type))) {
                e += E || "";
                continue
            }
            switch (u.type) {
                case "space":
                    continue;
                case "hr":
                    {
                        e += this.renderer.hr();
                        continue
                    }
                case "heading":
                    {
                        e += this.renderer.heading(this.parseInline(u.tokens), u.depth, pt(this.parseInline(u.tokens, this.textRenderer)), this.slugger);
                        continue
                    }
                case "code":
                    {
                        e += this.renderer.code(u.text, u.lang, u.escaped);
                        continue
                    }
                case "table":
                    {
                        for (m = "", d = "", a = u.header.length, i = 0; i < a; i++) d += this.renderer.tablecell(this.parseInline(u.header[i].tokens), {
                            header: !0,
                            align: u.align[i]
                        });
                        for (m += this.renderer.tablerow(d), f = "", a = u.rows.length, i = 0; i < a; i++) {
                            for (c = u.rows[i], d = "", o = c.length, l = 0; l < o; l++) d += this.renderer.tablecell(this.parseInline(c[l].tokens), {
                                header: !1,
                                align: u.align[l]
                            });
                            f += this.renderer.tablerow(d)
                        }
                        e += this.renderer.table(m, f);
                        continue
                    }
                case "blockquote":
                    {
                        f = this.parse(u.tokens),
                        e += this.renderer.blockquote(f);
                        continue
                    }
                case "list":
                    {
                        for (T = u.ordered, A = u.start, q = u.loose, a = u.items.length, f = "", i = 0; i < a; i++) b = u.items[i],
                        L = b.checked,
                        B = b.task,
                        w = "",
                        b.task && (R = this.renderer.checkbox(L), q ? b.tokens.length > 0 && b.tokens[0].type === "paragraph" ? (b.tokens[0].text = R + " " + b.tokens[0].text, b.tokens[0].tokens && b.tokens[0].tokens.length > 0 && b.tokens[0].tokens[0].type === "text" && (b.tokens[0].tokens[0].text = R + " " + b.tokens[0].tokens[0].text)) : b.tokens.unshift({
                            type: "text",
                            text: R
                        }) : w += R),
                        w += this.parse(b.tokens, q),
                        f += this.renderer.listitem(w, B, L);e += this.renderer.list(f, T, A);
                        continue
                    }
                case "html":
                    {
                        e += this.renderer.html(u.text, u.block);
                        continue
                    }
                case "paragraph":
                    {
                        e += this.renderer.paragraph(this.parseInline(u.tokens));
                        continue
                    }
                case "text":
                    {
                        for (f = u.tokens ? this.parseInline(u.tokens) : u.text; r + 1 < Z && t[r + 1].type === "text";) u = t[++r],
                        f += `
` + (u.tokens ? this.parseInline(u.tokens) : u.text);e += n ? this.renderer.paragraph(f) : f;
                        continue
                    }
                default:
                    {
                        const D = 'Token with "' + u.type + '" type was not found.';
                        if (this.options.silent) {
                            console.error(D);
                            return
                        } else throw new Error(D)
                    }
            }
        }
        return e
    }
    parseInline(t, n) {
        n = n || this.renderer;
        let e = "",
            r, i, l;
        const a = t.length;
        for (r = 0; r < a; r++) {
            if (i = t[r], this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type] && (l = this.options.extensions.renderers[i.type].call({
                    parser: this
                }, i), l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type))) {
                e += l || "";
                continue
            }
            switch (i.type) {
                case "escape":
                    {
                        e += n.text(i.text);
                        break
                    }
                case "html":
                    {
                        e += n.html(i.text);
                        break
                    }
                case "link":
                    {
                        e += n.link(i.href, i.title, this.parseInline(i.tokens, n));
                        break
                    }
                case "image":
                    {
                        e += n.image(i.href, i.title, i.text);
                        break
                    }
                case "strong":
                    {
                        e += n.strong(this.parseInline(i.tokens, n));
                        break
                    }
                case "em":
                    {
                        e += n.em(this.parseInline(i.tokens, n));
                        break
                    }
                case "codespan":
                    {
                        e += n.codespan(i.text);
                        break
                    }
                case "br":
                    {
                        e += n.br();
                        break
                    }
                case "del":
                    {
                        e += n.del(this.parseInline(i.tokens, n));
                        break
                    }
                case "text":
                    {
                        e += n.text(i.text);
                        break
                    }
                default:
                    {
                        const o = 'Token with "' + i.type + '" type was not found.';
                        if (this.options.silent) {
                            console.error(o);
                            return
                        } else throw new Error(o)
                    }
            }
        }
        return e
    }
}
class $e {
    constructor(t) {
        this.options = t || ce
    }
    preprocess(t) {
        return t
    }
    postprocess(t) {
        return t
    }
}
U($e, "passThroughHooks", new Set(["preprocess", "postprocess"]));
var ye, Fe, Ee, dt;
class Jt {
    constructor(...t) {
        Ne(this, ye);
        Ne(this, Ee);
        U(this, "defaults", We());
        U(this, "options", this.setOptions);
        U(this, "parse", Re(this, ye, Fe).call(this, Y.lex, K.parse));
        U(this, "parseInline", Re(this, ye, Fe).call(this, Y.lexInline, K.parseInline));
        U(this, "Parser", K);
        U(this, "parser", K.parse);
        U(this, "Renderer", Ce);
        U(this, "TextRenderer", Xe);
        U(this, "Lexer", Y);
        U(this, "lexer", Y.lex);
        U(this, "Tokenizer", Pe);
        U(this, "Slugger", Oe);
        U(this, "Hooks", $e);
        this.use(...t)
    }
    walkTokens(t, n) {
        let e = [];
        for (const r of t) switch (e = e.concat(n.call(this, r)), r.type) {
            case "table":
                {
                    for (const i of r.header) e = e.concat(this.walkTokens(i.tokens, n));
                    for (const i of r.rows)
                        for (const l of i) e = e.concat(this.walkTokens(l.tokens, n));
                    break
                }
            case "list":
                {
                    e = e.concat(this.walkTokens(r.items, n));
                    break
                }
            default:
                this.defaults.extensions && this.defaults.extensions.childTokens && this.defaults.extensions.childTokens[r.type] ? this.defaults.extensions.childTokens[r.type].forEach(i => {
                    e = e.concat(this.walkTokens(r[i], n))
                }) : r.tokens && (e = e.concat(this.walkTokens(r.tokens, n)))
        }
        return e
    }
    use(...t) {
        const n = this.defaults.extensions || {
            renderers: {},
            childTokens: {}
        };
        return t.forEach(e => {
            const r = { ...e
            };
            if (r.async = this.defaults.async || r.async || !1, e.extensions && (e.extensions.forEach(i => {
                    if (!i.name) throw new Error("extension name required");
                    if (i.renderer) {
                        const l = n.renderers[i.name];
                        l ? n.renderers[i.name] = function(...a) {
                            let o = i.renderer.apply(this, a);
                            return o === !1 && (o = l.apply(this, a)), o
                        } : n.renderers[i.name] = i.renderer
                    }
                    if (i.tokenizer) {
                        if (!i.level || i.level !== "block" && i.level !== "inline") throw new Error("extension level must be 'block' or 'inline'");
                        n[i.level] ? n[i.level].unshift(i.tokenizer) : n[i.level] = [i.tokenizer], i.start && (i.level === "block" ? n.startBlock ? n.startBlock.push(i.start) : n.startBlock = [i.start] : i.level === "inline" && (n.startInline ? n.startInline.push(i.start) : n.startInline = [i.start]))
                    }
                    i.childTokens && (n.childTokens[i.name] = i.childTokens)
                }), r.extensions = n), e.renderer) {
                const i = this.defaults.renderer || new Ce(this.defaults);
                for (const l in e.renderer) {
                    const a = i[l];
                    i[l] = (...o) => {
                        let c = e.renderer[l].apply(i, o);
                        return c === !1 && (c = a.apply(i, o)), c
                    }
                }
                r.renderer = i
            }
            if (e.tokenizer) {
                const i = this.defaults.tokenizer || new Pe(this.defaults);
                for (const l in e.tokenizer) {
                    const a = i[l];
                    i[l] = (...o) => {
                        let c = e.tokenizer[l].apply(i, o);
                        return c === !1 && (c = a.apply(i, o)), c
                    }
                }
                r.tokenizer = i
            }
            if (e.hooks) {
                const i = this.defaults.hooks || new $e;
                for (const l in e.hooks) {
                    const a = i[l];
                    $e.passThroughHooks.has(l) ? i[l] = o => {
                        if (this.defaults.async) return Promise.resolve(e.hooks[l].call(i, o)).then(d => a.call(i, d));
                        const c = e.hooks[l].call(i, o);
                        return a.call(i, c)
                    } : i[l] = (...o) => {
                        let c = e.hooks[l].apply(i, o);
                        return c === !1 && (c = a.apply(i, o)), c
                    }
                }
                r.hooks = i
            }
            if (e.walkTokens) {
                const i = this.defaults.walkTokens;
                r.walkTokens = function(l) {
                    let a = [];
                    return a.push(e.walkTokens.call(this, l)), i && (a = a.concat(i.call(this, l))), a
                }
            }
            this.defaults = { ...this.defaults,
                ...r
            }
        }), this
    }
    setOptions(t) {
        return this.defaults = { ...this.defaults,
            ...t
        }, this
    }
}
ye = new WeakSet, Fe = function(t, n) {
    return (e, r, i) => {
        typeof r == "function" && (i = r, r = null);
        const l = { ...r
        };
        r = { ...this.defaults,
            ...l
        };
        const a = Re(this, Ee, dt).call(this, r.silent, r.async, i);
        if (typeof e > "u" || e === null) return a(new Error("marked(): input parameter is undefined or null"));
        if (typeof e != "string") return a(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(e) + ", string expected"));
        if (Gt(r, i), r.hooks && (r.hooks.options = r), i) {
            const o = r.highlight;
            let c;
            try {
                r.hooks && (e = r.hooks.preprocess(e)), c = t(e, r)
            } catch (f) {
                return a(f)
            }
            const d = f => {
                let u;
                if (!f) try {
                    r.walkTokens && this.walkTokens(c, r.walkTokens), u = n(c, r), r.hooks && (u = r.hooks.postprocess(u))
                } catch (T) {
                    f = T
                }
                return r.highlight = o, f ? a(f) : i(null, u)
            };
            if (!o || o.length < 3 || (delete r.highlight, !c.length)) return d();
            let m = 0;
            this.walkTokens(c, f => {
                f.type === "code" && (m++, setTimeout(() => {
                    o(f.text, f.lang, (u, T) => {
                        if (u) return d(u);
                        T != null && T !== f.text && (f.text = T, f.escaped = !0), m--, m === 0 && d()
                    })
                }, 0))
            }), m === 0 && d();
            return
        }
        if (r.async) return Promise.resolve(r.hooks ? r.hooks.preprocess(e) : e).then(o => t(o, r)).then(o => r.walkTokens ? Promise.all(this.walkTokens(o, r.walkTokens)).then(() => o) : o).then(o => n(o, r)).then(o => r.hooks ? r.hooks.postprocess(o) : o).catch(a);
        try {
            r.hooks && (e = r.hooks.preprocess(e));
            const o = t(e, r);
            r.walkTokens && this.walkTokens(o, r.walkTokens);
            let c = n(o, r);
            return r.hooks && (c = r.hooks.postprocess(c)), c
        } catch (o) {
            return a(o)
        }
    }
}, Ee = new WeakSet, dt = function(t, n, e) {
    return r => {
        if (r.message += `
Please report this to https://github.com/markedjs/marked.`, t) {
            const i = "<p>An error occurred:</p><pre>" + O(r.message + "", !0) + "</pre>";
            if (n) return Promise.resolve(i);
            if (e) {
                e(null, i);
                return
            }
            return i
        }
        if (n) return Promise.reject(r);
        if (e) {
            e(r);
            return
        }
        throw r
    }
};
const ke = new Jt(ce);

function v(s, t, n) {
    return ke.parse(s, t, n)
}
v.options = v.setOptions = function(s) {
    return ke.setOptions(s), v.defaults = ke.defaults, ct(v.defaults), v
};
v.getDefaults = We;
v.defaults = ce;
v.use = function(...s) {
    return ke.use(...s), v.defaults = ke.defaults, ct(v.defaults), v
};
v.walkTokens = function(s, t) {
    return ke.walkTokens(s, t)
};
v.parseInline = ke.parseInline;
v.Parser = K;
v.parser = K.parse;
v.Renderer = Ce;
v.TextRenderer = Xe;
v.Lexer = Y;
v.lexer = Y.lex;
v.Tokenizer = Pe;
v.Slugger = Oe;
v.Hooks = $e;
v.parse = v;
v.options;
v.setOptions;
v.use;
v.walkTokens;
v.parseInline;
K.parse;
Y.lex;
const ft = {};
var Kt = z("<h1><!></h1>"),
    en = z("<h2><!></h2>"),
    tn = z("<h3><!></h3>"),
    nn = z("<h4><!></h4>"),
    rn = z("<h5><!></h5>"),
    sn = z("<h6><!></h6>");

function ln(s, t) {
    Le(t, !1);
    const n = oe();
    let e = y(t, "depth"),
        r = y(t, "raw"),
        i = y(t, "text");
    const {
        slug: l,
        getOptions: a
    } = It(ft), o = a();
    fe(() => ge(i()), () => {
        ie(n, o.headerIds ? o.headerPrefix + l(i()) : void 0)
    }), at(), Be();
    var c = x(),
        d = k(c);
    N(d, () => e() === 1, m => {
        var f = Kt(),
            u = I(f);
        P(u, C(t), {}, null), S(f), j(() => H(f, "id", $(n))), p(m, f)
    }, m => {
        var f = x(),
            u = k(f);
        N(u, () => e() === 2, T => {
            var A = en(),
                q = I(A);
            P(q, C(t), {}, null), S(A), j(() => H(A, "id", $(n))), p(T, A)
        }, T => {
            var A = x(),
                q = k(A);
            N(q, () => e() === 3, w => {
                var b = tn(),
                    L = I(b);
                P(L, C(t), {}, null), S(b), j(() => H(b, "id", $(n))), p(w, b)
            }, w => {
                var b = x(),
                    L = k(b);
                N(L, () => e() === 4, B => {
                    var R = nn(),
                        E = I(R);
                    P(E, C(t), {}, null), S(R), j(() => H(R, "id", $(n))), p(B, R)
                }, B => {
                    var R = x(),
                        E = k(R);
                    N(E, () => e() === 5, Z => {
                        var D = rn(),
                            M = I(D);
                        P(M, C(t), {}, null), S(D), j(() => H(D, "id", $(n))), p(Z, D)
                    }, Z => {
                        var D = x(),
                            M = k(D);
                        N(M, () => e() === 6, W => {
                            var Q = sn(),
                                X = I(Q);
                            P(X, C(t), {}, null), S(Q), j(() => H(Q, "id", $(n))), p(W, Q)
                        }, W => {
                            var Q = lt();
                            j(() => De(Q, r())), p(W, Q)
                        }, !0), p(Z, D)
                    }, !0), p(B, R)
                }, !0), p(w, b)
            }, !0), p(T, A)
        }, !0), p(m, f)
    }), p(s, c), qe()
}
var an = z("<p><!></p>");

function on(s, t) {
    var n = an(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}

function cn(s, t) {
    y(t, "text")(), y(t, "raw")();
    var r = x(),
        i = k(r);
    P(i, C(t), {}, null), p(s, r)
}
var un = z("<img>");

function hn(s, t) {
    let n = y(t, "href", 0, ""),
        e = y(t, "title", 0, void 0),
        r = y(t, "text", 0, "");
    var i = un();
    j(() => {
        H(i, "src", n()), H(i, "title", e()), H(i, "alt", r())
    }), p(s, i)
}
var pn = z("<a><!></a>");

function dn(s, t) {
    let n = y(t, "href", 0, ""),
        e = y(t, "title", 0, void 0);
    var r = pn(),
        i = I(r);
    P(i, C(t), {}, null), S(r), j(() => {
        H(r, "href", n()), H(r, "title", e())
    }), p(s, r)
}
var fn = z("<em><!></em>");

function gn(s, t) {
    var n = fn(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}
var mn = z("<del><!></del>");

function kn(s, t) {
    var n = mn(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}
var xn = z("<code> </code>");

function bn(s, t) {
    Le(t, !1);
    let n = y(t, "raw");
    Be();
    var e = xn(),
        r = I(e);
    j(() => De(r, n().replace(/`/g, ""))), S(e), p(s, e), qe()
}
var wn = z("<strong><!></strong>");

function _n(s, t) {
    var n = wn(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}
var vn = z("<table><!></table>");

function $n(s, t) {
    var n = vn(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}
var yn = z("<thead><!></thead>");

function zn(s, t) {
    var n = yn(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}
var Tn = z("<tbody><!></tbody>");

function Rn(s, t) {
    var n = Tn(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}
var Sn = z("<tr><!></tr>");

function In(s, t) {
    var n = Sn(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}
var An = z("<th><!></th>"),
    Pn = z("<td><!></td>");

function Cn(s, t) {
    let n = y(t, "header"),
        e = y(t, "align");
    var r = x(),
        i = k(r);
    N(i, n, l => {
        var a = An(),
            o = I(a);
        P(o, C(t), {}, null), S(a), j(() => H(a, "align", e())), p(l, a)
    }, l => {
        var a = Pn(),
            o = I(a);
        P(o, C(t), {}, null), S(a), j(() => H(a, "align", e())), p(l, a)
    }), p(s, r)
}
var En = z("<ol><!></ol>"),
    Ln = z("<ul><!></ul>");

function qn(s, t) {
    let n = y(t, "ordered"),
        e = y(t, "start");
    var r = x(),
        i = k(r);
    N(i, n, l => {
        var a = En(),
            o = I(a);
        P(o, C(t), {}, null), S(a), j(() => H(a, "start", e())), p(l, a)
    }, l => {
        var a = Ln(),
            o = I(a);
        P(o, C(t), {}, null), S(a), p(l, a)
    }), p(s, r)
}
var Bn = z("<li><!></li>");

function Dn(s, t) {
    var n = Bn(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}
var On = z("<hr>");

function Zn(s) {
    var t = On();
    p(s, t)
}

function Un(s, t) {
    let n = y(t, "text");
    var e = x(),
        r = k(e);
    Lt(r, n, !1, !1), p(s, e)
}
var jn = z("<blockquote><!></blockquote>");

function Mn(s, t) {
    var n = jn(),
        e = I(n);
    P(e, C(t), {}, null), S(n), p(s, n)
}
var Qn = z("<pre><code> </code></pre>");

function Nn(s, t) {
    let n = y(t, "lang"),
        e = y(t, "text");
    var r = Qn(),
        i = I(r),
        l = I(i);
    S(i), S(r), j(() => {
        Et(r, n()), De(l, e())
    }), p(s, r)
}
var Hn = z("<br><!>", 1);

function Fn(s, t) {
    var n = Hn(),
        e = k(n),
        r = He(e);
    P(r, C(t), {}, null), p(s, n)
}
const Wn = {
        heading: ln,
        paragraph: on,
        text: cn,
        image: hn,
        link: dn,
        em: gn,
        strong: _n,
        codespan: bn,
        del: kn,
        table: $n,
        tablehead: zn,
        tablebody: Rn,
        tablerow: In,
        tablecell: Cn,
        list: qn,
        orderedlistitem: null,
        unorderedlistitem: null,
        listitem: Dn,
        hr: Zn,
        html: Un,
        blockquote: Mn,
        code: Nn,
        br: Fn
    },
    Xn = {
        baseUrl: null,
        breaks: !1,
        gfm: !0,
        headerIds: !0,
        headerPrefix: "",
        highlight: null,
        langPrefix: "language-",
        mangle: !0,
        pedantic: !1,
        renderer: null,
        sanitize: !1,
        sanitizer: null,
        silent: !1,
        smartLists: !1,
        smartypants: !1,
        tokenizer: null,
        xhtml: !1
    };

function cr(s, t) {
    Le(t, !1);
    const n = oe(),
        e = oe(),
        r = oe(),
        i = oe();
    let l = y(t, "source", 8, () => []),
        a = y(t, "renderers", 8, () => ({})),
        o = y(t, "options", 8, () => ({})),
        c = y(t, "isInline", 0, !1);
    const d = Pt();
    let m = oe(),
        f = oe(),
        u = oe();
    At(ft, {
        slug: T => $(e) ? $(e).slug(T) : "",
        getOptions: () => $(r)
    }), ot(() => {
        ie(u, !0)
    }), fe(() => ge(l()), () => {
        ie(n, Array.isArray(l()))
    }), fe(() => ge(l()), () => {
        ie(e, l() ? new Oe : void 0)
    }), fe(() => ge(o()), () => {
        ie(r, { ...Xn,
            ...o()
        })
    }), fe(() => ($(n), $(m), ge(l()), $(f), $(r), ge(c())), () => {
        $(n) ? ie(m, l()) : (ie(f, new Y($(r))), ie(m, c() ? $(f).inlineTokens(l()) : $(f).lex(l())), d("parsed", {
            tokens: $(m)
        }))
    }), fe(() => ge(a()), () => {
        ie(i, { ...Wn,
            ...a()
        })
    }), fe(() => ($(u), $(n), $(m)), () => {
        $(u) && !$(n) && d("parsed", {
            tokens: $(m)
        })
    }), at(), Be(), me(s, {
        get tokens() {
            return $(m)
        },
        get renderers() {
            return $(i)
        },
        $$legacy: !0
    }), qe()
}
export {
    cr as S
};