import {
    q as $,
    E as X,
    h as C,
    o as L,
    g as j,
    u as ee,
    v as F,
    w as O,
    i as x,
    x as re,
    y as D,
    z as M,
    A as m,
    B as ae,
    C as ne,
    D as le
} from "./disclose-version.91b4a1e6.js";
import {
    l as fe,
    I as se,
    T as Z,
    v as G,
    o as ie,
    U as te,
    q as ue,
    A as U,
    s as K,
    m as ve,
    f as Q,
    V as oe,
    W as _e,
    L as de,
    D as ce,
    F as he,
    S as Ee
} from "./runtime.712ce216.js";
let k = null;

function ye(s, e) {
    return e
}

function Ae(s, e, a, u) {
    for (var v = [], o = e.length, i = 0; i < o; i++) oe(e[i].e, v, !0);
    var E = o > 0 && v.length === 0 && a !== null;
    if (E) {
        var A = a.parentNode;
        ae(A), A.append(a), u.clear(), y(s, e[0].prev, e[o - 1].next)
    }
    _e(v, () => {
        for (var h = 0; h < o; h++) {
            var _ = e[h];
            E || (u.delete(_.k), y(s, _.prev, _.next)), de(_.e, !E)
        }
    })
}

function Ce(s, e, a, u, v, o = null) {
    var i = s,
        E = {
            flags: e,
            items: new Map,
            first: null
        },
        A = (e & X) !== 0;
    if (A) {
        var h = s;
        i = C ? L(h.firstChild) : h.appendChild($())
    }
    C && j();
    var _ = null;
    fe(() => {
        var n = a(),
            d = se(n) ? n : n == null ? [] : Array.from(n),
            l = d.length,
            t = E.flags;
        t & m && !ce(d) && !(he in d) && !(Ee in d) && (t ^= m, t & le && !(t & D) && (t ^= D));
        let c = !1;
        if (C) {
            var T = i.data === ee;
            T !== (l === 0) && (i = F(), L(i), O(!1), c = !0)
        }
        if (C) {
            for (var S = null, p, r = 0; r < l; r++) {
                if (x.nodeType === 8 && x.data === re) {
                    i = x, c = !0, O(!1);
                    break
                }
                var f = d[r],
                    N = u(f, r);
                p = J(x, E, S, null, f, N, r, v, t), E.items.set(N, p), S = p
            }
            l > 0 && L(F())
        }
        C || pe(d, E, i, v, t, u), o !== null && (l === 0 ? _ ? Z(_) : _ = G(() => o(i)) : _ !== null && ie(_, () => {
            _ = null
        })), c && O(!0)
    }), C && (i = x)
}

function pe(s, e, a, u, v, o) {
    var b, q, B, V;
    var i = (v & ne) !== 0,
        E = (v & (D | M)) !== 0,
        A = s.length,
        h = e.items,
        _ = e.first,
        n = _,
        d = new Set,
        l = null,
        t = new Set,
        c = [],
        T = [],
        S, p, r, f;
    if (i)
        for (f = 0; f < A; f += 1) S = s[f], p = o(S, f), r = h.get(p), r !== void 0 && ((b = r.a) == null || b.measure(), t.add(r));
    for (f = 0; f < A; f += 1) {
        if (S = s[f], p = o(S, f), r = h.get(p), r === void 0) {
            var N = n ? n.e.nodes.start : a;
            l = J(N, e, l, l === null ? e.first : l.next, S, p, f, u, v), h.set(p, l), c = [], T = [], n = l.next;
            continue
        }
        if (E && Te(r, S, f, v), r.e.f & te && (Z(r.e), i && ((q = r.a) == null || q.unfix(), t.delete(r))), r !== n) {
            if (d.has(r)) {
                if (c.length < T.length) {
                    var R = T[0],
                        g;
                    l = R.prev;
                    var Y = c[0],
                        H = c[c.length - 1];
                    for (g = 0; g < c.length; g += 1) W(c[g], R, a);
                    for (g = 0; g < T.length; g += 1) d.delete(T[g]);
                    y(e, Y.prev, H.next), y(e, l, Y), y(e, H, R), n = R, l = H, f -= 1, c = [], T = []
                } else d.delete(r), W(r, n, a), y(e, r.prev, r.next), y(e, r, l === null ? e.first : l.next), y(e, l, r), l = r;
                continue
            }
            for (c = [], T = []; n !== null && n.k !== p;) d.add(n), T.push(n), n = n.next;
            if (n === null) continue;
            r = n
        }
        c.push(r), l = r, n = r.next
    }
    const I = Array.from(d);
    for (; n !== null;) I.push(n), n = n.next;
    var w = I.length;
    if (w > 0) {
        var P = v & X && A === 0 ? a : null;
        if (i) {
            for (f = 0; f < w; f += 1)(B = I[f].a) == null || B.measure();
            for (f = 0; f < w; f += 1)(V = I[f].a) == null || V.fix()
        }
        Ae(e, I, P, h)
    }
    i && ue(() => {
        var z;
        for (r of t)(z = r.a) == null || z.apply()
    }), U.first = e.first && e.first.e, U.last = l && l.e
}

function Te(s, e, a, u) {
    u & D && K(s.v, e), u & M ? K(s.i, a) : s.i = a
}

function J(s, e, a, u, v, o, i, E, A) {
    var h = k;
    try {
        var _ = (A & D) !== 0,
            n = (A & m) === 0,
            d = _ ? n ? ve(v) : Q(v) : v,
            l = A & M ? Q(i) : i,
            t = {
                i: l,
                v: d,
                k: o,
                a: null,
                e: null,
                prev: a,
                next: u
            };
        return k = t, t.e = G(() => E(s, d, l), C), t.e.prev = a && a.e, t.e.next = u && u.e, a === null ? e.first = t : (a.next = t, a.e.next = t.e), u !== null && (u.prev = t, u.e.prev = t.e), t
    } finally {
        k = h
    }
}

function W(s, e, a) {
    for (var u = s.next ? s.next.e.nodes.start : a, v = e ? e.e.nodes.start : a, o = s.e.nodes.start; o !== u;) {
        var i = o.nextSibling;
        v.before(o), o = i
    }
}

function y(s, e, a) {
    e === null ? s.first = a : (e.next = a, e.e.next = a && a.e), a !== null && (a.prev = e, a.e.prev = e && e.e)
}
export {
    Ce as e, ye as i
};