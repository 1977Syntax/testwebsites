import {
    A as m
} from "./runtime.712ce216.js";
const D = 1,
    w = 2,
    b = 4,
    L = 8,
    P = 16,
    x = 64,
    H = 1,
    M = 2,
    U = 4,
    k = 8,
    Y = 1,
    $ = 2,
    B = 4,
    T = 1,
    C = 2,
    N = "[",
    S = "[!",
    R = "]",
    F = {},
    V = Symbol(),
    G = ["beforeinput", "click", "change", "dblclick", "contextmenu", "focusin", "focusout", "input", "keydown", "keyup", "mousedown", "mousemove", "mouseout", "mouseover", "mouseup", "pointerdown", "pointermove", "pointerout", "pointerover", "pointerup", "touchend", "touchmove", "touchstart"],
    W = ["touchstart", "touchmove", "touchend"],
    K = {
        formnovalidate: "formNoValidate",
        ismap: "isMap",
        nomodule: "noModule",
        playsinline: "playsInline",
        readonly: "readOnly"
    };

function Z(e, t = "exclude-on") {
    return e.endsWith("capture") ? t == "exclude-on" ? e !== "gotpointercapture" && e !== "lostpointercapture" : e !== "ongotpointercapture" && e !== "onlostpointercapture" : !1
}
let s = !1;

function j(e) {
    s = e
}
let r;

function d(e) {
    return r = e
}

function E() {
    return r = r.nextSibling
}

function q(e) {
    s && (r = e)
}

function z() {
    s && E()
}

function J() {
    for (var e = 0, t = r;;) {
        if (t.nodeType === 8) {
            var n = t.data;
            if (n === R) {
                if (e === 0) return t;
                e -= 1
            } else(n === N || n === S) && (e += 1)
        }
        var a = t.nextSibling;
        t.remove(), t = a
    }
}
var v, O;

function Q() {
    if (v === void 0) {
        v = window, O = document;
        var e = Element.prototype;
        e.__click = void 0, e.__className = "", e.__attributes = null, e.__e = void 0, Text.prototype.__t = void 0
    }
}

function c() {
    return document.createTextNode("")
}

function X(e) {
    if (!s) return e.firstChild;
    var t = r.firstChild;
    return t === null && (t = r.appendChild(c())), d(t), t
}

function ee(e, t) {
    if (!s) {
        var n = e.firstChild;
        return n instanceof Comment && n.data === "" ? n.nextSibling : n
    }
    if (t && (r == null ? void 0 : r.nodeType) !== 3) {
        var a = c();
        return r == null || r.before(a), d(a), a
    }
    return r
}

function te(e, t = !1) {
    if (!s) return e.nextSibling;
    var n = r.nextSibling,
        a = n.nodeType;
    if (t && a !== 3) {
        var o = c();
        return n == null || n.before(o), d(o), o
    }
    return d(n), n
}

function ne(e) {
    e.textContent = ""
}

function I(e) {
    var t = document.createElement("template");
    return t.innerHTML = e, t.content
}

function u(e, t) {
    var n;
    (n = m).nodes ? ? (n.nodes = {
        start: e,
        end: t
    })
}

function re(e, t) {
    var n = (t & T) !== 0,
        a = (t & C) !== 0,
        o, _ = !e.startsWith("<!>");
    return () => {
        if (s) return u(r, null), r;
        o || (o = I(_ ? e : "<!>" + e), n || (o = o.firstChild));
        var i = a ? document.importNode(o, !0) : o.cloneNode(!0);
        if (n) {
            var p = i.firstChild,
                f = i.lastChild;
            u(p, f)
        } else u(i, i);
        return i
    }
}

function oe(e, t, n = "svg") {
    var a = !e.startsWith("<!>"),
        o = (t & T) !== 0,
        _ = `<${n}>${a?e:"<!>"+e}</${n}>`,
        i;
    return () => {
        if (s) return u(r, null), r;
        if (!i) {
            var p = I(_),
                f = p.firstChild;
            if (o)
                for (i = document.createDocumentFragment(); f.firstChild;) i.appendChild(f.firstChild);
            else i = f.firstChild
        }
        var l = i.cloneNode(!0);
        if (o) {
            var h = l.firstChild,
                A = l.lastChild;
            u(h, A)
        } else u(l, l);
        return l
    }
}

function ae() {
    if (!s) {
        var e = c();
        return u(e, e), e
    }
    var t = r;
    return t.nodeType !== 3 && (t.before(t = c()), d(t)), u(t, t), t
}

function ie() {
    if (s) return u(r, null), r;
    var e = document.createDocumentFragment(),
        t = document.createComment(""),
        n = c();
    return e.append(t, n), u(t, n), e
}

function se(e, t) {
    if (s) {
        m.nodes.end = r, E();
        return
    }
    e !== null && e.before(t)
}
const g = "5";
typeof window < "u" && (window.__svelte || (window.__svelte = {
    v: new Set
})).v.add(g);
export {
    v as $, x as A, ne as B, P as C, b as D, L as E, N as F, Q as G, F as H, Z as I, K as J, G as K, U as L, H as M, M as N, k as O, W as P, Y as T, V as U, se as a, X as b, ie as c, ae as d, z as e, ee as f, E as g, s as h, r as i, $ as j, B as k, O as l, u as m, oe as n, d as o, I as p, c as q, q as r, te as s, re as t, S as u, J as v, j as w, R as x, D as y, w as z
};