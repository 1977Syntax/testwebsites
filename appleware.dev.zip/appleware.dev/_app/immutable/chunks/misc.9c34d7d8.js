import {
    h as n,
    g as d
} from "./disclose-version.91b4a1e6.js";

function u(e, t, i, r) {
    n && d(), t === void 0 ? r !== null && r(e) : t(e, i)
}

function l(e) {
    var i;
    var t = (i = e.$$slots) == null ? void 0 : i.default;
    return t === !0 ? e.children : t
}
export {
    l as d, u as s
};