import {
    D as w,
    F as b,
    S as o,
    G as R,
    H as P,
    d as x,
    f as m,
    I,
    s as c,
    J as h,
    g as y,
    A as O,
    u as S,
    K as T
} from "./runtime.712ce216.js";
import {
    U as u
} from "./disclose-version.91b4a1e6.js";

function _(e, t = null, s) {
    if (typeof e == "object" && e != null && !w(e) && !(b in e)) {
        if (o in e) {
            const n = e[o];
            if (n.t === e || n.p === e) return n.p
        }
        const f = T(e);
        if (f === R || f === P) {
            const n = new Proxy(e, A);
            return x(e, o, {
                value: {
                    s: new Map,
                    v: m(0),
                    a: I(e),
                    p: n,
                    t: e
                },
                writable: !0,
                enumerable: !1
            }), n
        }
    }
    return e
}

function g(e, t = 1) {
    c(e, e.v + t)
}
const A = {
    defineProperty(e, t, s) {
        if (s.value) {
            const f = e[o],
                n = f.s.get(t);
            n !== void 0 && c(n, _(s.value, f))
        }
        return Reflect.defineProperty(e, t, s)
    },
    deleteProperty(e, t) {
        const s = e[o],
            f = s.s.get(t),
            n = s.a,
            i = delete e[t];
        if (n && i) {
            const a = s.s.get("length"),
                l = e.length - 1;
            a !== void 0 && a.v !== l && c(a, l)
        }
        return f !== void 0 && c(f, u), i && g(s.v), i
    },
    get(e, t, s) {
        var i;
        if (t === o) return Reflect.get(e, o);
        const f = e[o];
        let n = f.s.get(t);
        if (n === void 0 && (!(t in e) || (i = h(e, t)) != null && i.writable) && (n = m(_(e[t], f)), f.s.set(t, n)), n !== void 0) {
            const a = y(n);
            return a === u ? void 0 : a
        }
        return Reflect.get(e, t, s)
    },
    getOwnPropertyDescriptor(e, t) {
        const s = Reflect.getOwnPropertyDescriptor(e, t);
        if (s && "value" in s) {
            const n = e[o].s.get(t);
            n && (s.value = y(n))
        }
        return s
    },
    has(e, t) {
        var i;
        if (t === o) return !0;
        const s = e[o],
            f = Reflect.has(e, t);
        let n = s.s.get(t);
        return (n !== void 0 || O !== null && (!f || (i = h(e, t)) != null && i.writable)) && (n === void 0 && (n = m(f ? _(e[t], s) : u), s.s.set(t, n)), y(n) === u) ? !1 : f
    },
    set(e, t, s, f) {
        const n = e[o];
        let i = n.s.get(t);
        i === void 0 && (S(() => f[t]), i = n.s.get(t)), i !== void 0 && c(i, _(s, n));
        const a = n.a,
            l = !(t in e);
        if (a && t === "length")
            for (let r = s; r < e.length; r += 1) {
                const d = n.s.get(r + "");
                d !== void 0 && c(d, u)
            }
        if (e[t] = s, l) {
            if (a) {
                const r = n.s.get("length"),
                    d = e.length;
                r !== void 0 && r.v !== d && c(r, d)
            }
            g(n.v)
        }
        return !0
    },
    ownKeys(e) {
        const t = e[o];
        return y(t.v), Reflect.ownKeys(e)
    }
};
export {
    _ as p
};