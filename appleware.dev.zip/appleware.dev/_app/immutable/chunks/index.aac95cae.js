import {
    y as F,
    E as z,
    B,
    z as L,
    e as U,
    u as j,
    A as P,
    C as W,
    q as D
} from "./runtime.712ce216.js";
import {
    a as G
} from "./render.95e1ab5e.js";
import {
    T as K,
    j as b,
    k as H
} from "./disclose-version.91b4a1e6.js";
const M = typeof window < "u",
    J = M ? requestAnimationFrame : F,
    Q = M ? () => performance.now() : () => Date.now(),
    l = {
        tick: r => J(r),
        now: () => Q(),
        tasks: new Set
    };

function O(r) {
    l.tasks.forEach(t => {
        t.c(r) || (l.tasks.delete(t), t.f())
    }), l.tasks.size !== 0 && l.tick(O)
}

function V(r) {
    let t;
    return l.tasks.size === 0 && l.tick(O), {
        promise: new Promise(a => {
            l.tasks.add(t = {
                c: r,
                f: a
            })
        }),
        abort() {
            l.tasks.delete(t)
        }
    }
}

function w(r, t) {
    r.dispatchEvent(new CustomEvent(t))
}

function X(r) {
    const t = r.split("-");
    return t.length === 1 ? t[0] : t[0] + t.slice(1).map(a => a[0].toUpperCase() + a.slice(1)).join("")
}

function S(r) {
    const t = {},
        a = r.split(";");
    for (const o of a) {
        const [s, n] = o.split(":");
        if (!s || n === void 0) break;
        const _ = X(s.trim());
        t[_] = n.trim()
    }
    return t
}
const Y = r => r;

function et(r, t, a, o) {
    var s = (r & K) !== 0,
        n = (r & b) !== 0,
        _ = (r & H) !== 0,
        c = s && n ? "both" : s ? "in" : "out",
        u, p = t.inert,
        e, f, v;

    function h() {
        return u ? ? (u = a()(t, o == null ? void 0 : o(), {
            direction: c
        }))
    }
    var m = {
            is_global: _,
            in () {
                t.inert = p, f == null || f.abort(), s ? (w(t, "introstart"), e = C(t, h(), f, 1, () => {
                    w(t, "introend"), e = u = void 0
                })) : v == null || v()
            },
            out(i) {
                n ? (t.inert = !0, w(t, "outrostart"), f = C(t, h(), e, 0, () => {
                    w(t, "outroend"), f = u = void 0, i == null || i()
                }), v = f.reset) : i == null || i()
            },
            stop: () => {
                e == null || e.abort(), f == null || f.abort()
            }
        },
        $ = P;
    if (($.transitions ? ? ($.transitions = [])).push(m), s && G) {
        let i = _;
        if (!i) {
            for (var d = $.parent; d && d.f & z;)
                for (;
                    (d = d.parent) && !(d.f & B););
            i = !d || (d.f & L) !== 0
        }
        i && U(() => {
            j(() => m.in())
        })
    }
}

function C(r, t, a, o, s) {
    var n = o === 1;
    if (W(t)) {
        var _;
        return D(() => {
            var y = t({
                direction: n ? "in" : "out"
            });
            _ = C(r, y, a, o, s)
        }), {
            abort: () => _.abort(),
            deactivate: () => _.deactivate(),
            reset: () => _.reset(),
            t: y => _.t(y)
        }
    }
    if (a == null || a.deactivate(), !(t != null && t.duration)) return s == null || s(), {
        abort: F,
        deactivate: F,
        reset: F,
        t: () => o
    };
    var {
        delay: c = 0,
        duration: u,
        css: p,
        tick: e,
        easing: f = Y
    } = t, v = l.now() + c, h = (a == null ? void 0 : a.t(v)) ? ? 1 - o, m = o - h;
    u *= Math.abs(m);
    var $ = v + u,
        d, i;
    if (p) {
        var T = [],
            E = Math.ceil(u / 16.666666666666668);
        if (n && c > 0) {
            let y = Math.ceil(c / 16.666666666666668),
                g = S(p(0, 1));
            for (let A = 0; A < y; A += 1) T.push(g)
        }
        for (var x = 0; x <= E; x += 1) {
            var N = h + m * f(x / E),
                q = p(N, 1 - N);
            T.push(S(q))
        }
        d = r.animate(T, {
            delay: n ? 0 : c,
            duration: u + (n ? c : 0),
            easing: "linear",
            fill: "forwards"
        }), d.finished.then(() => {
            s == null || s(), o === 1 && d.cancel()
        }).catch(y => {
            if (d.startTime !== null && d.currentTime !== null) throw y
        })
    } else h === 0 && (e == null || e(0, 1)), i = V(y => {
        if (y >= $) return e == null || e(o, 1 - o), s == null || s(), !1;
        if (y >= v) {
            var g = h + m * f((y - v) / u);
            e == null || e(g, 1 - g)
        }
        return !0
    });
    return {
        abort: () => {
            d == null || d.cancel(), i == null || i.abort()
        },
        deactivate: () => {
            s = void 0
        },
        reset: () => {
            o === 0 && (e == null || e(1, 0))
        },
        t: y => {
            var g = h + m * f((y - v) / u);
            return Math.min(1, Math.max(0, g))
        }
    }
}
const Z = r => r;

function R(r) {
    const t = r - 1;
    return t * t * t + 1
}

function I(r) {
    const t = typeof r == "string" && r.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
    return t ? [parseFloat(t[1]), t[2] || "px"] : [r, "px"]
}

function it(r, {
    delay: t = 0,
    duration: a = 400,
    easing: o = Z
} = {}) {
    const s = +getComputedStyle(r).opacity;
    return {
        delay: t,
        duration: a,
        easing: o,
        css: n => `opacity: ${n*s}`
    }
}

function st(r, {
    delay: t = 0,
    duration: a = 400,
    easing: o = R,
    x: s = 0,
    y: n = 0,
    opacity: _ = 0
} = {}) {
    const c = getComputedStyle(r),
        u = +c.opacity,
        p = c.transform === "none" ? "" : c.transform,
        e = u * (1 - _),
        [f, v] = I(s),
        [h, m] = I(n);
    return {
        delay: t,
        duration: a,
        easing: o,
        css: ($, d) => `
			transform: ${p} translate(${(1-$)*f}${v}, ${(1-$)*h}${m});
			opacity: ${u-e*d}`
    }
}

function nt(r, {
    delay: t = 0,
    duration: a = 400,
    easing: o = R,
    axis: s = "y"
} = {}) {
    const n = getComputedStyle(r),
        _ = +n.opacity,
        c = s === "y" ? "height" : "width",
        u = parseFloat(n[c]),
        p = s === "y" ? ["top", "bottom"] : ["left", "right"],
        e = p.map(i => `${i[0].toUpperCase()}${i.slice(1)}`),
        f = parseFloat(n[`padding${e[0]}`]),
        v = parseFloat(n[`padding${e[1]}`]),
        h = parseFloat(n[`margin${e[0]}`]),
        m = parseFloat(n[`margin${e[1]}`]),
        $ = parseFloat(n[`border${e[0]}Width`]),
        d = parseFloat(n[`border${e[1]}Width`]);
    return {
        delay: t,
        duration: a,
        easing: o,
        css: i => `overflow: hidden;opacity: ${Math.min(i*20,1)*_};${c}: ${i*u}px;padding-${p[0]}: ${i*f}px;padding-${p[1]}: ${i*v}px;margin-${p[0]}: ${i*h}px;margin-${p[1]}: ${i*m}px;border-${p[0]}-width: ${i*$}px;border-${p[1]}-width: ${i*d}px;`
    }
}
export {
    it as a, st as f, nt as s, et as t
};