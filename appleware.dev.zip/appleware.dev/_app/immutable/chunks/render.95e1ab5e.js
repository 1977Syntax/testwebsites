import {
    q as L,
    F as N,
    H as y,
    w as u,
    o as O,
    g as I,
    i as g,
    x as S,
    G as T,
    B as Y,
    h as m,
    m as $,
    P as C
} from "./disclose-version.91b4a1e6.js";
import {
    Z as A,
    _ as M,
    $ as P,
    a0 as V,
    v as k,
    p as q,
    A as B,
    c as F,
    Q as G
} from "./runtime.712ce216.js";
import {
    a as Q,
    r as E,
    b as W,
    c as l
} from "./svelte-head.5f7b6b5a.js";

function Z(a) {
    console.warn("hydration_mismatch")
}
let R = !0;

function U(a, e) {
    (a.__t ? ? (a.__t = a.nodeValue)) !== e && (a.nodeValue = a.__t = e)
}

function j(a, e) {
    const s = e.anchor ? ? e.target.appendChild(L());
    return A(() => D(a, { ...e,
        anchor: s
    }), !1)
}

function X(a, e) {
    e.intro = e.intro ? ? !1;
    const s = e.target,
        c = m;
    try {
        return A(() => {
            for (var r = s.firstChild; r && (r.nodeType !== 8 || r.data !== N);) r = r.nextSibling;
            if (!r) throw y;
            u(!0), O(r), I();
            const i = D(a, { ...e,
                anchor: r
            });
            if (g.nodeType !== 8 || g.data !== S) throw Z(), y;
            return u(!1), i
        }, !1)
    } catch (r) {
        if (r === y) return e.recover === !1 && M(), T(), Y(s), u(!1), j(a, e);
        throw r
    } finally {
        u(c), W()
    }
}
const d = new Map;

function D(a, {
    target: e,
    anchor: s,
    props: c = {},
    events: r,
    context: i,
    intro: b = !0
}) {
    T();
    var h = new Set,
        _ = t => {
            for (var o = 0; o < t.length; o++) {
                var n = t[o];
                if (!h.has(n)) {
                    h.add(n);
                    var p = C.includes(n);
                    e.addEventListener(n, l, {
                        passive: p
                    });
                    var w = d.get(n);
                    w === void 0 ? (document.addEventListener(n, l, {
                        passive: p
                    }), d.set(n, 1)) : d.set(n, w + 1)
                }
            }
        };
    _(P(Q)), E.add(_);
    var f = void 0,
        H = V(() => (k(() => {
            if (i) {
                q({});
                var t = G;
                t.c = i
            }
            r && (c.$$events = r), m && $(s, null), R = b, f = a(s, c) || {}, R = !0, m && (B.nodes.end = g), i && F()
        }), () => {
            for (var t of h) {
                e.removeEventListener(t, l);
                var o = d.get(t);
                --o === 0 ? (document.removeEventListener(t, l), d.delete(t)) : d.set(t, o)
            }
            E.delete(_), v.delete(f)
        }));
    return v.set(f, H), f
}
let v = new WeakMap;

function x(a) {
    const e = v.get(a);
    e == null || e()
}
export {
    R as a, Z as b, X as h, j as m, U as s, x as u
};