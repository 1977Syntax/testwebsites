import {
    l as T,
    T as r,
    v as n,
    o,
    E
} from "./runtime.712ce216.js";
import {
    h as t,
    g as y,
    u as g,
    v as p,
    o as A,
    w as u,
    i as R
} from "./disclose-version.91b4a1e6.js";

function S(_, c, d, i = null, h = !1) {
    t && y();
    var e = _,
        a = null,
        s = null,
        f = null,
        m = h ? E : 0;
    T(() => {
        if (f === (f = !!c())) return;
        let l = !1;
        if (t) {
            const v = e.data === g;
            f === v && (e = p(), A(e), u(!1), l = !0)
        }
        f ? (a ? r(a) : a = n(() => d(e)), s && o(s, () => {
            s = null
        })) : (s ? r(s) : i && (s = n(() => i(e))), a && o(a, () => {
            a = null
        })), l && u(!0)
    }, m), t && (e = R)
}
export {
    S as i
};