import {
    j as o
} from "./singletons.9d8d5935.js";
const e = o("goto");
export {
    e as g
};