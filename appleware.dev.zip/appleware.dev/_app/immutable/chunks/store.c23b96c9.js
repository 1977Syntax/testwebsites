import {
    y as r,
    M as i,
    m as o,
    s as f,
    g as t
} from "./runtime.712ce216.js";

function l(s, e, n) {
    if (s == null) return e(void 0), n && n(void 0), r;
    const u = s.subscribe(e, n);
    return u.unsubscribe ? () => u.unsubscribe() : u
}

function a(s, e, n) {
    const u = n[e] ? ? (n[e] = {
        store: null,
        source: o(void 0),
        unsubscribe: r
    });
    if (u.store !== s)
        if (u.unsubscribe(), u.store = s ? ? null, s == null) f(u.source, void 0), u.unsubscribe = r;
        else {
            var c = !0;
            u.unsubscribe = l(s, b => {
                c ? (u.source.v = b, c = !1) : f(u.source, b)
            })
        }
    return t(u.source)
}

function p() {
    const s = {};
    return i(() => {
        for (var e in s) s[e].unsubscribe()
    }), s
}
export {
    a,
    p as s
};