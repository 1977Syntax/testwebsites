var un = Array.isArray,
    ln = Array.from,
    sn = Object.isFrozen,
    on = Object.defineProperty,
    fn = Object.getOwnPropertyDescriptor,
    Nt = Object.getOwnPropertyDescriptors,
    an = Object.prototype,
    _n = Array.prototype,
    jt = Object.getPrototypeOf;

function cn(t) {
    return typeof t == "function"
}
const k = 2,
    lt = 4,
    F = 8,
    st = 16,
    E = 32,
    W = 64,
    x = 128,
    L = 256,
    d = 512,
    m = 1024,
    b = 2048,
    C = 4096,
    D = 8192,
    It = 16384,
    ot = 32768,
    vn = 65536,
    Mt = 1 << 18,
    X = Symbol("$state"),
    pn = Symbol("$state.frozen"),
    hn = Symbol("");

function ft(t) {
    return t === this.v
}

function Lt(t, n) {
    return t != t ? n == n : t !== n || t !== null && typeof t == "object" || typeof t == "function"
}

function it(t) {
    return !Lt(t, this.v)
}

function Yt(t) {
    throw new Error("effect_in_teardown")
}

function Pt() {
    throw new Error("effect_in_unowned_derived")
}

function Bt(t) {
    throw new Error("effect_orphan")
}

function Ht() {
    throw new Error("effect_update_depth_exceeded")
}

function wn() {
    throw new Error("hydration_failed")
}

function dn(t) {
    throw new Error("props_invalid_value")
}

function Ut() {
    throw new Error("state_unsafe_mutation")
}

function at(t) {
    return {
        f: 0,
        v: t,
        reactions: null,
        equals: ft,
        version: 0
    }
}

function En(t) {
    var r;
    const n = at(t);
    return n.equals = it, f !== null && f.l !== null && ((r = f.l).s ? ? (r.s = [])).push(n), n
}

function _t(t, n) {
    return a !== null && G() && a.f & k && Ut(), t.equals(n) || (t.v = n, t.version = Ot(), ct(t, m), G() && i !== null && i.f & d && !(i.f & E) && (c !== null && c.includes(t) ? (h(i, m), z(i)) : y === null ? Jt([t]) : y.push(t))), n
}

function ct(t, n) {
    var r = t.reactions;
    if (r !== null)
        for (var e = G(), l = r.length, u = 0; u < l; u++) {
            var s = r[u],
                o = s.f;
            o & m || !e && s === i || (h(s, n), o & (d | x) && (o & k ? ct(s, b) : z(s)))
        }
}

function vt(t) {
    i === null && a === null && Bt(), a !== null && a.f & x && Pt(), Z && Yt()
}

function tt(t, n) {
    var r = n.last;
    r === null ? n.last = n.first = t : (r.next = t, t.prev = r, n.last = t)
}

function R(t, n, r, e = !0) {
    var l = (t & W) !== 0,
        u = {
            ctx: f,
            deps: null,
            nodes: null,
            f: t | m,
            first: null,
            fn: n,
            last: null,
            next: null,
            parent: l ? null : i,
            prev: null,
            teardown: null,
            transitions: null,
            version: 0
        };
    if (r) {
        var s = S;
        try {
            nt(!0), I(u), u.f |= It
        } catch (_) {
            throw H(u), _
        } finally {
            nt(s)
        }
    } else n !== null && z(u);
    var o = r && u.deps === null && u.first === null && u.nodes === null && u.teardown === null;
    return !o && !l && e && (i !== null && tt(u, i), a !== null && a.f & k && tt(u, a)), u
}

function yn(t) {
    const n = R(F, null, !1);
    return h(n, d), n.teardown = t, n
}

function mn(t) {
    vt();
    var n = i !== null && (i.f & F) !== 0 && f !== null && !f.m;
    if (n) {
        var r = f;
        (r.e ? ? (r.e = [])).push(t)
    } else {
        var e = pt(t);
        return e
    }
}

function gn(t) {
    return vt(), B(t)
}

function kn(t) {
    const n = R(W, t, !0);
    return () => {
        H(n)
    }
}

function pt(t) {
    return R(lt, t, !1)
}

function xn(t, n) {
    var r = f,
        e = {
            effect: null,
            ran: !1
        };
    r.l.r1.push(e), e.effect = B(() => {
        t(), !e.ran && (e.ran = !0, _t(r.l.r2, !0), tn(n))
    })
}

function Tn() {
    var t = f;
    B(() => {
        if (Q(t.l.r2)) {
            for (var n of t.l.r1) {
                var r = n.effect;
                N(r) && I(r), n.ran = !1
            }
            t.l.r2.v = !1
        }
    })
}

function B(t) {
    return R(F, t, !0)
}

function qn(t) {
    return B(t)
}

function On(t, n = 0) {
    return R(F | st | n, t, !0)
}

function Sn(t, n = !0) {
    return R(F | E, t, !0, n)
}

function ht(t) {
    var n = t.teardown;
    if (n !== null) {
        const r = Z,
            e = a;
        rt(!0), et(null);
        try {
            n.call(null)
        } finally {
            rt(r), et(e)
        }
    }
}

function H(t, n = !0) {
    var r = !1;
    if ((n || t.f & Mt) && t.nodes !== null) {
        for (var e = t.nodes.start, l = t.nodes.end; e !== null;) {
            var u = e === l ? null : e.nextSibling;
            e.remove(), e = u
        }
        r = !0
    }
    if (J(t, n && !r), U(t, 0), h(t, D), t.transitions)
        for (const o of t.transitions) o.stop();
    ht(t);
    var s = t.parent;
    s !== null && t.f & E && s.first !== null && wt(t), t.next = t.prev = t.teardown = t.ctx = t.deps = t.parent = t.fn = t.nodes = null
}

function wt(t) {
    var n = t.parent,
        r = t.prev,
        e = t.next;
    r !== null && (r.next = e), e !== null && (e.prev = r), n !== null && (n.first === t && (n.first = e), n.last === t && (n.last = r))
}

function An(t, n) {
    var r = [];
    dt(t, r, !0), zt(r, () => {
        H(t), n && n()
    })
}

function zt(t, n) {
    var r = t.length;
    if (r > 0) {
        var e = () => --r || n();
        for (var l of t) l.out(e)
    } else n()
}

function dt(t, n, r) {
    if (!(t.f & C)) {
        if (t.f ^= C, t.transitions !== null)
            for (const s of t.transitions)(s.is_global || r) && n.push(s);
        for (var e = t.first; e !== null;) {
            var l = e.next,
                u = (e.f & ot) !== 0 || (e.f & E) !== 0;
            dt(e, n, u ? r : !1), e = l
        }
    }
}

function Cn(t) {
    Et(t, !0)
}

function Et(t, n) {
    if (t.f & C) {
        t.f ^= C, N(t) && I(t);
        for (var r = t.first; r !== null;) {
            var e = r.next,
                l = (r.f & ot) !== 0 || (r.f & E) !== 0;
            Et(r, l ? n : !1), r = e
        }
        if (t.transitions !== null)
            for (const u of t.transitions)(u.is_global || n) && u.in()
    }
}
const Fn = () => {};

function bn(t) {
    return t()
}

function yt(t) {
    for (var n = 0; n < t.length; n++) t[n]()
}
const Kt = typeof requestIdleCallback > "u" ? t => setTimeout(t, 1) : requestIdleCallback;
let Y = !1,
    P = !1,
    K = [],
    $ = [];

function mt() {
    Y = !1;
    const t = K.slice();
    K = [], yt(t)
}

function gt() {
    P = !1;
    const t = $.slice();
    $ = [], yt(t)
}

function Dn(t) {
    Y || (Y = !0, queueMicrotask(mt)), K.push(t)
}

function Rn(t) {
    P || (P = !0, Kt(gt)), $.push(t)
}

function $t() {
    Y && mt(), P && gt()
}

function Gt(t) {
    let n = k | m;
    i === null && (n |= x);
    const r = {
        deps: null,
        deriveds: null,
        equals: ft,
        f: n,
        first: null,
        fn: t,
        last: null,
        reactions: null,
        v: null,
        version: 0
    };
    if (a !== null && a.f & k) {
        var e = a;
        e.deriveds === null ? e.deriveds = [r] : e.deriveds.push(r)
    }
    return r
}

function Nn(t) {
    const n = Gt(t);
    return n.equals = it, n
}

function kt(t) {
    J(t);
    var n = t.deriveds;
    if (n !== null) {
        t.deriveds = null;
        for (var r = 0; r < n.length; r += 1) Vt(n[r])
    }
}

function xt(t) {
    kt(t);
    var n = St(t),
        r = (O || t.f & x) && t.deps !== null ? b : d;
    h(t, r), t.equals(n) || (t.v = n, t.version = Ot())
}

function Vt(t) {
    kt(t), U(t, 0), h(t, D), t.first = t.last = t.deps = t.reactions = t.fn = null
}

function Wt(t) {
    throw new Error("lifecycle_outside_component")
}
const Tt = 0,
    Zt = 1;
let M = Tt,
    j = !1,
    S = !1,
    Z = !1;

function nt(t) {
    S = t
}

function rt(t) {
    Z = t
}
let g = [],
    A = 0,
    a = null;

function et(t) {
    a = t
}
let i = null,
    c = null,
    v = 0,
    y = null;

function Jt(t) {
    y = t
}
let qt = 0,
    O = !1,
    f = null;

function Ot() {
    return qt++
}

function G() {
    return f !== null && f.l === null
}

function N(t) {
    var s, o;
    var n = t.f;
    if (n & m) return !0;
    if (n & b) {
        var r = t.deps;
        if (r !== null) {
            var e = (n & x) !== 0,
                l;
            if (n & L) {
                for (l = 0; l < r.length; l++)((s = r[l]).reactions ? ? (s.reactions = [])).push(t);
                t.f ^= L
            }
            for (l = 0; l < r.length; l++) {
                var u = r[l];
                if (N(u) && xt(u), u.version > t.version) return !0;
                e && !O && !((o = u == null ? void 0 : u.reactions) != null && o.includes(t)) && (u.reactions ? ? (u.reactions = [])).push(t)
            }
        }
        h(t, d)
    }
    return !1
}

function Qt(t, n, r) {
    throw t
}

function St(t) {
    var n = c,
        r = v,
        e = y,
        l = a,
        u = O;
    c = null, v = 0, y = null, a = t.f & (E | W) ? null : t, O = !S && (t.f & x) !== 0;
    try {
        var s = (0, t.fn)(),
            o = t.deps;
        if (c !== null) {
            var _, p;
            if (o !== null) {
                var T = v === 0 ? c : o.slice(0, v).concat(c),
                    q = T.length > 16 ? new Set(T) : null;
                for (p = v; p < o.length; p++) _ = o[p], (q !== null ? !q.has(_) : !T.includes(_)) && At(t, _)
            }
            if (o !== null && v > 0)
                for (o.length = v + c.length, p = 0; p < c.length; p++) o[v + p] = c[p];
            else t.deps = o = c;
            if (!O)
                for (p = v; p < o.length; p++) {
                    _ = o[p];
                    var w = _.reactions;
                    w === null ? _.reactions = [t] : w[w.length - 1] !== t && !w.includes(t) && w.push(t)
                }
        } else o !== null && v < o.length && (U(t, v), o.length = v);
        return s
    } finally {
        c = n, v = r, y = e, a = l, O = u
    }
}

function At(t, n) {
    const r = n.reactions;
    let e = 0;
    if (r !== null) {
        e = r.length - 1;
        const l = r.indexOf(t);
        l !== -1 && (e === 0 ? n.reactions = null : (r[l] = r[e], r.pop()))
    }
    e === 0 && n.f & k && (h(n, b), n.f & (x | L) || (n.f ^= L), U(n, 0))
}

function U(t, n) {
    var r = t.deps;
    if (r !== null)
        for (var e = n === 0 ? null : r.slice(0, n), l = new Set, u = n; u < r.length; u++) {
            var s = r[u];
            l.has(s) || (l.add(s), (e === null || !e.includes(s)) && At(t, s))
        }
}

function J(t, n = !1) {
    var r = t.first;
    for (t.first = t.last = null; r !== null;) {
        var e = r.next;
        H(r, n), r = e
    }
}

function I(t) {
    var n = t.f;
    if (!(n & D)) {
        h(t, d);
        var r = t.ctx,
            e = i,
            l = f;
        i = t, f = r;
        try {
            n & st || J(t), ht(t);
            var u = St(t);
            t.teardown = typeof u == "function" ? u : null, t.version = qt
        } catch (s) {
            Qt(s)
        } finally {
            i = e, f = l
        }
    }
}

function Ct() {
    A > 1e3 && (A = 0, Ht()), A++
}

function Ft(t) {
    var n = t.length;
    if (n !== 0) {
        Ct();
        var r = S;
        S = !0;
        try {
            for (var e = 0; e < n; e++) {
                var l = t[e];
                if (l.first === null && !(l.f & E)) ut([l]);
                else {
                    var u = [];
                    bt(l, u), ut(u)
                }
            }
        } finally {
            S = r
        }
    }
}

function ut(t) {
    var n = t.length;
    if (n !== 0)
        for (var r = 0; r < n; r++) {
            var e = t[r];
            !(e.f & (D | C)) && N(e) && (I(e), e.deps === null && e.first === null && e.nodes === null && (e.teardown === null ? wt(e) : e.fn = null))
        }
}

function Xt() {
    if (j = !1, A > 1001) return;
    const t = g;
    g = [], Ft(t), j || (A = 0)
}

function z(t) {
    M === Tt && (j || (j = !0, queueMicrotask(Xt)));
    for (var n = t; n.parent !== null;) {
        n = n.parent;
        var r = n.f;
        if (r & E) {
            if (!(r & d)) return;
            h(n, b)
        }
    }
    g.push(n)
}

function bt(t, n) {
    var r = t.first,
        e = [];
    t: for (; r !== null;) {
        var l = r.f,
            u = (l & (D | C)) === 0,
            s = l & E,
            o = (l & d) !== 0,
            _ = r.first;
        if (u && (!s || !o)) {
            if (s && h(r, d), l & F) {
                if (!s && N(r) && (I(r), _ = r.first), _ !== null) {
                    r = _;
                    continue
                }
            } else if (l & lt)
                if (s || o) {
                    if (_ !== null) {
                        r = _;
                        continue
                    }
                } else e.push(r)
        }
        var p = r.next;
        if (p === null) {
            let w = r.parent;
            for (; w !== null;) {
                if (t === w) break t;
                var T = w.next;
                if (T !== null) {
                    r = T;
                    continue t
                }
                w = w.parent
            }
        }
        r = p
    }
    for (var q = 0; q < e.length; q++) _ = e[q], n.push(_), bt(_, n)
}

function Dt(t, n = !0) {
    var r = M,
        e = g;
    try {
        Ct();
        const u = [];
        M = Zt, g = u, j = !1, n && Ft(e);
        var l = t == null ? void 0 : t();
        return $t(), (g.length > 0 || u.length > 0) && Dt(), A = 0, l
    } finally {
        M = r, g = e
    }
}
async function jn() {
    await Promise.resolve(), Dt()
}

function Q(t) {
    var n = t.f;
    if (n & D) return t.v;
    if (a !== null) {
        var r = a.deps;
        c === null && r !== null && r[v] === t ? v++ : (r === null || v === 0 || r[v - 1] !== t) && (c === null ? c = [t] : c[c.length - 1] !== t && c.push(t)), y !== null && i !== null && i.f & d && !(i.f & E) && y.includes(t) && (h(i, m), z(i))
    }
    if (n & k) {
        var e = t;
        N(e) && xt(e)
    }
    return t.v
}

function tn(t) {
    const n = a;
    try {
        return a = null, t()
    } finally {
        a = n
    }
}
const nn = ~(m | b | d);

function h(t, n) {
    t.f = t.f & nn | n
}

function rn(t) {
    return typeof t == "object" && t !== null && typeof t.f == "number"
}

function In(t) {
    return Rt().get(t)
}

function Mn(t, n) {
    return Rt().set(t, n), n
}

function Rt(t) {
    return f === null && Wt(), f.c ? ? (f.c = new Map(en(f) || void 0))
}

function en(t) {
    let n = t.p;
    for (; n !== null;) {
        const r = n.c;
        if (r !== null) return r;
        n = n.p
    }
    return null
}

function Ln(t, n = 1) {
    var r = +Q(t);
    return _t(t, r + n), r
}

function Yn(t, n = !1, r) {
    f = {
        p: f,
        c: null,
        e: null,
        m: !1,
        s: t,
        x: null,
        l: null
    }, n || (f.l = {
        s: null,
        u: null,
        r1: [],
        r2: at(!1)
    })
}

function Pn(t) {
    const n = f;
    if (n !== null) {
        t !== void 0 && (n.x = t);
        const e = n.e;
        if (e !== null) {
            n.e = null;
            for (var r = 0; r < e.length; r++) pt(e[r])
        }
        f = n.p, n.m = !0
    }
    return t || {}
}

function Bn(t) {
    if (!(typeof t != "object" || !t || t instanceof EventTarget)) {
        if (X in t) V(t);
        else if (!Array.isArray(t))
            for (let n in t) {
                const r = t[n];
                typeof r == "object" && r && X in r && V(r)
            }
    }
}

function V(t, n = new Set) {
    if (typeof t == "object" && t !== null && !(t instanceof EventTarget) && !n.has(t)) {
        n.add(t), t instanceof Date && t.getTime();
        for (let e in t) try {
            V(t[e], n)
        } catch {}
        const r = jt(t);
        if (r !== Object.prototype && r !== Array.prototype && r !== Map.prototype && r !== Set.prototype && r !== Date.prototype) {
            const e = Nt(r);
            for (let l in e) {
                const u = e[l].get;
                if (u) try {
                    u.call(t)
                } catch {}
            }
        }
    }
}

function Hn(t) {
    return rn(t) ? Q(t) : t
}
export {
    ln as $, i as A, st as B, cn as C, sn as D, ot as E, pn as F, an as G, _n as H, un as I, fn as J, jt as K, H as L, yn as M, Nn as N, Bn as O, Mn as P, f as Q, Wt as R, X as S, Cn as T, C as U, dt as V, zt as W, yt as X, bn as Y, Dt as Z, wn as _, gn as a, kn as a0, hn as a1, Rn as a2, Nt as a3, dn as a4, vn as a5, it as a6, Ln as a7, Mt as a8, mn as b, Pn as c, on as d, pt as e, at as f, Q as g, qn as h, Hn as i, Gt as j, In as k, On as l, En as m, Lt as n, An as o, Yn as p, Dn as q, B as r, _t as s, jn as t, tn as u, Sn as v, xn as w, Tn as x, Fn as y, It as z
};