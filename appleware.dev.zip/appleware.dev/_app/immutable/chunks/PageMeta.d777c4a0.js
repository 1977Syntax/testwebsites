import {
    f as b,
    s as e,
    l as u,
    a as A,
    t as W
} from "./disclose-version.91b4a1e6.js";
import {
    h as O
} from "./runtime.712ce216.js";
import {
    h as d
} from "./svelte-head.5f7b6b5a.js";
import {
    s as S
} from "./attributes.0fe580a6.js";
import {
    p as f
} from "./props.a974af4b.js";
var R = W('<meta name="keywords" content="Roblox exploits, Roblox hack tools, free Roblox exploits, Roblox exploit scripts, Roblox cheat engine, Roblox exploiting 2024, Roblox exploits download, Roblox exploit tutorials, Roblox hacks, best Roblox exploits, Roblox exploit forum, Roblox exploit executor, Roblox exploit for Mac, Roblox exploit for Windows, Roblox script executor, Roblox exploit injector, Roblox cheat codes, Roblox script hub, Roblox hack download, Roblox exploit without ban, Roblox exploits no virus, Roblox exploiting guide, Roblox cheats for beginners, Roblox exploit reviews, Roblox hacking tools free, Apple-Ware, Apple-Ware software, Apple-Ware app, Apple-Ware download, Apple-Ware for iOS, Apple-Ware reviews, Apple-Ware features, Apple-Ware updates, Apple-Ware support, Apple-Ware tutorial, Apple-Ware installation, Apple-Ware troubleshooting, Apple-Ware customer service, Apple-Ware product, Apple-Ware benefits, Apple-Ware pricing, Apple-Ware subscription, Apple-Ware compatibility, Apple-Ware alternatives, Apple-Ware FAQ, Apple-Ware guide, Apple-Ware setup, Apple-Ware premium, Apple-Ware free trial, Apple-Ware vs competitors, iOS apps, iOS updates, best iOS apps 2024, iOS development, iOS features, iOS 17, iOS tips and tricks, iOS security, iOS app development, iOS games, iOS beta, iOS tutorial, iOS jailbreak, iOS customization, iOS privacy settings, iOS performance, iOS support, iOS widgets, iOS settings, iOS productivity apps, iOS automation, iOS shortcuts, iOS troubleshooting, iOS reviews, iOS app store, Apple-Ware, AppleWare, Apple Ware Executor, Apple-Ware iOS, Apple-Ware Executor, AppleWare Roblox, AppleWare Download, Roblox AppleWare, iOS executor"> <meta name="description" content="Apple-Ware is a free-to-use iOS based mobile development tool for ROBLOX."> <meta name="author" content="Apple-Ware"> <meta name="robots" content="index, follow"> <meta property="og:type" content="website"> <meta property="og:url" content="https://appleware.dev/"> <meta property="og:title"> <meta property="og:description" content="Apple-Ware is the leading free-to-use iOS based mobile development tool for ROBLOX."> <meta name="theme-color" content="#F81CE5">', 1);

function $(v, r) {
    let o = f(r, "title");
    d(a => {
        var t = R(),
            i = b(t),
            l = e(e(i, !0)),
            s = e(e(l, !0)),
            n = e(e(s, !0)),
            m = e(e(n, !0)),
            x = e(e(m, !0)),
            p = e(e(x, !0)),
            c = e(e(p, !0)),
            g = e(e(c, !0));
        O(() => {
            u.title = `${o()??""} | Apple-Ware`, S(p, "content", `${o()??""} | Apple-Ware`)
        }), A(a, t)
    })
}
export {
    $ as P
};