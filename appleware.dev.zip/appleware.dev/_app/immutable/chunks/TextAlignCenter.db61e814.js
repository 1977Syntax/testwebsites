import {
    c as i,
    a,
    r as G,
    n as r,
    b as I,
    s as A,
    f as l,
    d as J
} from "./disclose-version.91b4a1e6.js";
import {
    p as K,
    k as N,
    h as z,
    c as O
} from "./runtime.712ce216.js";
import {
    s as Q
} from "./render.95e1ab5e.js";
import {
    i as o
} from "./if.c692dc35.js";
import {
    s as R,
    d as X
} from "./misc.9c34d7d8.js";
import {
    a as Y
} from "./attributes.0fe580a6.js";
import {
    i as a0
} from "./lifecycle.b2515c68.js";
import {
    l as C,
    p as c
} from "./props.a974af4b.js";
var t0 = r('<path d="M228,128a12,12,0,0,1-12,12H40a12,12,0,0,1,0-24H216A12,12,0,0,1,228,128ZM40,76H216a12,12,0,0,0,0-24H40a12,12,0,0,0,0,24ZM216,180H40a12,12,0,0,0,0,24H216a12,12,0,0,0,0-24Z"></path>'),
    r0 = r('<path d="M216,64V192H40V64Z" opacity="0.2"></path><path d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128ZM40,72H216a8,8,0,0,0,0-16H40a8,8,0,0,0,0,16ZM216,184H40a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Z"></path>', 1),
    e0 = r('<path d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM192,184H64a8,8,0,0,1,0-16H192a8,8,0,0,1,0,16Zm0-48H64a8,8,0,0,1,0-16H192a8,8,0,0,1,0,16Zm0-48H64a8,8,0,0,1,0-16H192a8,8,0,0,1,0,16Z"></path>'),
    o0 = r('<path d="M222,128a6,6,0,0,1-6,6H40a6,6,0,0,1,0-12H216A6,6,0,0,1,222,128ZM40,70H216a6,6,0,0,0,0-12H40a6,6,0,0,0,0,12ZM216,186H40a6,6,0,0,0,0,12H216a6,6,0,0,0,0-12Z"></path>'),
    i0 = r('<path d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128ZM40,72H216a8,8,0,0,0,0-16H40a8,8,0,0,0,0,16ZM216,184H40a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Z"></path>'),
    l0 = r('<path d="M220,128a4,4,0,0,1-4,4H40a4,4,0,0,1,0-8H216A4,4,0,0,1,220,128ZM40,68H216a4,4,0,0,0,0-8H40a4,4,0,0,0,0,8ZM216,188H40a4,4,0,0,0,0,8H216a4,4,0,0,0,0-8Z"></path>'),
    s0 = r('<svg><!><rect width="256" height="256" fill="none"></rect><!></svg>');

function x0(b, t) {
    const V = C(t, ["children", "$$slots", "$$events", "$$legacy"]),
        y = C(V, ["weight", "color", "size", "mirrored"]);
    K(t, !1);
    const {
        weight: $,
        color: k,
        size: B,
        mirrored: L,
        ...P
    } = N("iconCtx") || {};
    let e = c(t, "weight", 0, $ ? ? "regular"),
        S = c(t, "color", 0, k ? ? "currentColor"),
        M = c(t, "size", 0, B ? ? "1em"),
        T = c(t, "mirrored", 0, L || !1);
    a0();
    var s = s0();
    let w;
    var x = I(s);
    R(x, X(t), {}, null);
    var U = A(x),
        W = A(U);
    o(W, () => e() === "bold", g => {
        var n = t0();
        a(g, n)
    }, g => {
        var n = i(),
            j = l(n);
        o(j, () => e() === "duotone", _ => {
            var H = r0();
            a(_, H)
        }, _ => {
            var H = i(),
                q = l(H);
            o(q, () => e() === "fill", p => {
                var h = e0();
                a(p, h)
            }, p => {
                var h = i(),
                    D = l(h);
                o(D, () => e() === "light", f => {
                    var v = o0();
                    a(f, v)
                }, f => {
                    var v = i(),
                        E = l(v);
                    o(E, () => e() === "regular", Z => {
                        var d = i0();
                        a(Z, d)
                    }, Z => {
                        var d = i(),
                            F = l(d);
                        o(F, () => e() === "thin", u => {
                            var m = l0();
                            a(u, m)
                        }, u => {
                            var m = J();
                            z(() => Q(m, (console.error('Unsupported icon weight. Choose from "thin", "light", "regular", "bold", "fill", or "duotone".'), ""))), a(u, m)
                        }, !0), a(Z, d)
                    }, !0), a(f, v)
                }, !0), a(p, h)
            }, !0), a(_, H)
        }, !0), a(g, n)
    }), G(s), z(() => w = Y(s, w, {
        xmlns: "http://www.w3.org/2000/svg",
        width: M(),
        height: M(),
        fill: S(),
        transform: T() ? "scale(-1, 1)" : void 0,
        viewBox: "0 0 256 256",
        ...P,
        ...y
    }, !1, "")), a(b, s), O()
}
var n0 = r('<path d="M28,64A12,12,0,0,1,40,52H216a12,12,0,0,1,0,24H40A12,12,0,0,1,28,64ZM64,92a12,12,0,0,0,0,24H192a12,12,0,0,0,0-24Zm152,40H40a12,12,0,0,0,0,24H216a12,12,0,0,0,0-24Zm-24,40H64a12,12,0,0,0,0,24H192a12,12,0,0,0,0-24Z"></path>'),
    H0 = r('<path d="M216,64V168a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V64Z" opacity="0.2"></path><path d="M32,64a8,8,0,0,1,8-8H216a8,8,0,0,1,0,16H40A8,8,0,0,1,32,64ZM64,96a8,8,0,0,0,0,16H192a8,8,0,0,0,0-16Zm152,40H40a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Zm-24,40H64a8,8,0,0,0,0,16H192a8,8,0,0,0,0-16Z"></path>', 1),
    h0 = r('<path d="M208,32H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM176,184H80a8,8,0,0,1,0-16h96a8,8,0,0,1,0,16Zm16-32H64a8,8,0,0,1,0-16H192a8,8,0,0,1,0,16ZM72,112a8,8,0,0,1,8-8h96a8,8,0,0,1,0,16H80A8,8,0,0,1,72,112ZM192,88H64a8,8,0,0,1,0-16H192a8,8,0,0,1,0,16Z"></path>'),
    v0 = r('<path d="M34,64a6,6,0,0,1,6-6H216a6,6,0,0,1,0,12H40A6,6,0,0,1,34,64ZM64,98a6,6,0,0,0,0,12H192a6,6,0,0,0,0-12Zm152,40H40a6,6,0,0,0,0,12H216a6,6,0,0,0,0-12Zm-24,40H64a6,6,0,0,0,0,12H192a6,6,0,0,0,0-12Z"></path>'),
    d0 = r('<path d="M32,64a8,8,0,0,1,8-8H216a8,8,0,0,1,0,16H40A8,8,0,0,1,32,64ZM64,96a8,8,0,0,0,0,16H192a8,8,0,0,0,0-16Zm152,40H40a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Zm-24,40H64a8,8,0,0,0,0,16H192a8,8,0,0,0,0-16Z"></path>'),
    m0 = r('<path d="M36,64a4,4,0,0,1,4-4H216a4,4,0,0,1,0,8H40A4,4,0,0,1,36,64Zm28,36a4,4,0,0,0,0,8H192a4,4,0,0,0,0-8Zm152,40H40a4,4,0,0,0,0,8H216a4,4,0,0,0,0-8Zm-24,40H64a4,4,0,0,0,0,8H192a4,4,0,0,0,0-8Z"></path>'),
    c0 = r('<svg><!><rect width="256" height="256" fill="none"></rect><!></svg>');

function A0(b, t) {
    const V = C(t, ["children", "$$slots", "$$events", "$$legacy"]),
        y = C(V, ["weight", "color", "size", "mirrored"]);
    K(t, !1);
    const {
        weight: $,
        color: k,
        size: B,
        mirrored: L,
        ...P
    } = N("iconCtx") || {};
    let e = c(t, "weight", 0, $ ? ? "regular"),
        S = c(t, "color", 0, k ? ? "currentColor"),
        M = c(t, "size", 0, B ? ? "1em"),
        T = c(t, "mirrored", 0, L || !1);
    a0();
    var s = c0();
    let w;
    var x = I(s);
    R(x, X(t), {}, null);
    var U = A(x),
        W = A(U);
    o(W, () => e() === "bold", g => {
        var n = n0();
        a(g, n)
    }, g => {
        var n = i(),
            j = l(n);
        o(j, () => e() === "duotone", _ => {
            var H = H0();
            a(_, H)
        }, _ => {
            var H = i(),
                q = l(H);
            o(q, () => e() === "fill", p => {
                var h = h0();
                a(p, h)
            }, p => {
                var h = i(),
                    D = l(h);
                o(D, () => e() === "light", f => {
                    var v = v0();
                    a(f, v)
                }, f => {
                    var v = i(),
                        E = l(v);
                    o(E, () => e() === "regular", Z => {
                        var d = d0();
                        a(Z, d)
                    }, Z => {
                        var d = i(),
                            F = l(d);
                        o(F, () => e() === "thin", u => {
                            var m = m0();
                            a(u, m)
                        }, u => {
                            var m = J();
                            z(() => Q(m, (console.error('Unsupported icon weight. Choose from "thin", "light", "regular", "bold", "fill", or "duotone".'), ""))), a(u, m)
                        }, !0), a(Z, d)
                    }, !0), a(f, v)
                }, !0), a(p, h)
            }, !0), a(_, H)
        }, !0), a(g, n)
    }), G(s), z(() => w = Y(s, w, {
        xmlns: "http://www.w3.org/2000/svg",
        width: M(),
        height: M(),
        fill: S(),
        transform: T() ? "scale(-1, 1)" : void 0,
        viewBox: "0 0 256 256",
        ...P,
        ...y
    }, !1, "")), a(b, s), O()
}
export {
    x0 as L, A0 as T
};