import {
    M as E,
    q as T,
    d as m,
    I as S,
    l as k,
    a8 as q
} from "./runtime.712ce216.js";
import {
    q as x,
    h as g,
    F as A,
    o as b,
    i as C
} from "./disclose-version.91b4a1e6.js";
const D = new Set,
    F = new Set;

function L(a, r, i, t) {
    function n(e) {
        if (t.capture || O.call(r, e), !e.cancelBubble) return i.call(this, e)
    }
    return a.startsWith("pointer") || a === "wheel" ? T(() => {
        r.addEventListener(a, n, t)
    }) : r.addEventListener(a, n, t), n
}

function I(a, r, i, t, n) {
    var e = {
            capture: t,
            passive: n
        },
        l = L(a, r, i, e);
    (r === document.body || r === window || r === document) && E(() => {
        r.removeEventListener(a, l, e)
    })
}

function M(a) {
    for (var r = 0; r < a.length; r++) D.add(a[r]);
    for (var i of F) i(a)
}

function O(a) {
    var y;
    var r = this,
        i = r.ownerDocument,
        t = a.type,
        n = ((y = a.composedPath) == null ? void 0 : y.call(a)) || [],
        e = n[0] || a.target,
        l = 0,
        h = a.__root;
    if (h) {
        var u = n.indexOf(h);
        if (u !== -1 && (r === document || r === window)) {
            a.__root = r;
            return
        }
        var _ = n.indexOf(r);
        if (_ === -1) return;
        u <= _ && (l = u)
    }
    if (e = n[l] || a.target, e !== r) {
        m(a, "currentTarget", {
            configurable: !0,
            get() {
                return e || i
            }
        });
        try {
            for (var d, p = []; e !== null;) {
                var c = e.parentNode || e.host || null;
                try {
                    var s = e["__" + t];
                    if (s !== void 0 && !e.disabled)
                        if (S(s)) {
                            var [w, ...v] = s;
                            w.apply(e, [a, ...v])
                        } else s.call(e, a)
                } catch (f) {
                    d ? p.push(f) : d = f
                }
                if (a.cancelBubble || c === r || c === null) break;
                e = c
            }
            if (d) {
                for (let f of p) queueMicrotask(() => {
                    throw f
                });
                throw d
            }
        } finally {
            a.__root = r, e = r
        }
    }
}
let o;

function N() {
    o = void 0
}

function R(a) {
    let r = null,
        i = g;
    var t;
    if (g) {
        for (r = C, o === void 0 && (o = document.head.firstChild); o.nodeType !== 8 || o.data !== A;) o = o.nextSibling;
        o = b(o.nextSibling)
    } else t = document.head.appendChild(x());
    try {
        k(() => a(t), q)
    } finally {
        i && b(r)
    }
}
export {
    D as a, N as b, O as c, M as d, I as e, L as f, R as h, F as r
};